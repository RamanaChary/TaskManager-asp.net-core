﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;

namespace XTGlobal.BusinessLogic.Task
{
    public interface ITaskCRUDManager
    {
		void Add(TaskDTO task);

		void Update(TaskDTO task);

		void Delete(int taskID);
	}
}
