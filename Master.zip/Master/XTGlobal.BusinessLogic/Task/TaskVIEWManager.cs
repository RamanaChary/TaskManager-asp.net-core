﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Task;

namespace XTGlobal.BusinessLogic.Task
{
	public class TaskVIEWManager : ITaskVIEWManager
	{
		private ITaskVIEWDAO _taskVIEWDAO = null;
		private IMapper _mapper = null; 
		public TaskVIEWManager(ITaskVIEWDAO taskVIEWDAO, IMapper mapper)
		{
			this._taskVIEWDAO = taskVIEWDAO;
			this._mapper = mapper;
		}

		public List<TaskDTO> GetAllTasks()
		{
			List<TaskDTO> taskList = _mapper.Map<List<TaskDataModel>, List<TaskDTO>> (_taskVIEWDAO.GetAllTasks());
			return taskList;
		}

		public List<TaskDTO> GetCompletedTasks()
		{
			List<TaskDTO> taskList = _mapper.Map<List<TaskDataModel>, List<TaskDTO>>(_taskVIEWDAO.GetCompletedTasks());
			return taskList;
		}

		public List<TaskDTO> GetOverDueTasks()
		{
			List<TaskDTO> taskList = _mapper.Map<List<TaskDataModel>, List<TaskDTO>>(_taskVIEWDAO.GetOverDueTasks());
			return taskList;
		}
	}
}
