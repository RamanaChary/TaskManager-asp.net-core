﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;

namespace XTGlobal.BusinessLogic.Task
{
    public interface ITaskVIEWManager
    {
		List<TaskDTO> GetAllTasks();
		List<TaskDTO> GetOverDueTasks();
		List<TaskDTO> GetCompletedTasks();
    }
}
