﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Task;

namespace XTGlobal.BusinessLogic.Task
{
	public class TaskCRUDManager : ITaskCRUDManager
	{
		private ITaskCRUDDAO _taskCRUDDAO = null;
		private IMapper _mapper = null;
		public TaskCRUDManager(ITaskCRUDDAO taskCRUDDAO, IMapper mapper)
		{
			this._taskCRUDDAO = taskCRUDDAO;
			this._mapper = mapper;
		}

		public void Add(TaskDTO task)
		{
			var model = _mapper.Map<TaskDataModel>(task);
			_taskCRUDDAO.Add(model);
		}

		public void Delete(int taskID)
		{
			_taskCRUDDAO.Delete(taskID);
		}

		public void Update(TaskDTO task)
		{
			var model = _mapper.Map<TaskDataModel>(task);
			_taskCRUDDAO.Update(model);
		}
	}
}
