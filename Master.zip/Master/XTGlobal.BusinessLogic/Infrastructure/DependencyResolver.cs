﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.BusinessLogic.Task;
using XTGlobal.DataAccess.Infrastructure;
using XTGlobal.DataAccess.Task;

namespace XTGlobal.BusinessLogic.Infrastructure
{
	/// <summary>
	/// Add application dependencies here 
	/// </summary>
    public static class DependencyResolver
    {
		public static void AddDependency(this IServiceCollection services)
		{
			//Inject application dependencies
			services.AddTransient<ITaskVIEWManager, TaskVIEWManager>();
			services.AddTransient<ITaskCRUDManager, TaskCRUDManager>();
			services.AddTransient<ITaskVIEWDAO, TaskVIEWDAO>();
			services.AddTransient<ITaskCRUDDAO, TaskCRUDDAO>();
			services.AddTransient<IDataSource, DataSource>();
		}
    }
}
