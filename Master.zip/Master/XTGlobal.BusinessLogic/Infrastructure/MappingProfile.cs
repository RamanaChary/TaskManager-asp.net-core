﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.BusinessLogic.Infrastructure
{
    public class MappingProfile : Profile
    {
		public MappingProfile()
		{
			// Add as many of these lines as you need to map your objects
			CreateMap<TaskDTO, TaskDataModel>();
			CreateMap<TaskDataModel, TaskDTO>();
		}
	}
}
