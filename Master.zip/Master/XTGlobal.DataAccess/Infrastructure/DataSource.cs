﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Infrastructure
{
	/// <summary>
	/// In memory data source
	/// This should be replaced by a DBContext/Repository
	/// </summary>
	public class DataSource : IDataSource
	{
		private static List<TaskDataModel> userTasks = new List<TaskDataModel>();

		public void Add(TaskDataModel task)
		{
			userTasks.Add(task);
		}

		public void Update(TaskDataModel task)
		{
			TaskDataModel tempTask = userTasks.Find(t => t.TaskID == task.TaskID);

			if (tempTask != null)
			{
				tempTask.Title = task.Title;
				tempTask.Description = task.Description;
				tempTask.DueDate = task.DueDate;
				tempTask.IsCompleted = task.IsCompleted;
				tempTask.UserID = task.UserID;
			}
		}

		public void Delete(int taskID)
		{
			TaskDataModel tempTask = userTasks.Find(t => t.TaskID == taskID);

			if (tempTask != null)
			{
				userTasks.Remove(tempTask);
			}
		}

		public List<TaskDataModel> Tasks
		{
			get
			{
				return userTasks;
			}
		}
	}
}
