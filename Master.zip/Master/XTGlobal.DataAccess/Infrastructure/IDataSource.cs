﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Infrastructure
{
    public interface IDataSource
    {
		void Add(TaskDataModel task);

		void Update(TaskDataModel task);

		void Delete(int taskID);

		List<TaskDataModel> Tasks { get; }
	}
}
