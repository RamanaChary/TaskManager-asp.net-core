﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.DataAccess.Entity.EntityDataModels
{
    public class TaskDataModel
    {
		public int TaskID { get; set; }
		public string Title { get; set; }
		public string Description { get; set; }
		public DateTime DueDate { get; set; }
		public int? UserID { get; set; }
		public bool IsCompleted { get; set; }
	}
}
