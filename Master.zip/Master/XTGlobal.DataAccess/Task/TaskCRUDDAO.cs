﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Infrastructure;

namespace XTGlobal.DataAccess.Task
{
	public class TaskCRUDDAO : ITaskCRUDDAO
	{
		private IDataSource _dataSource = null;

		public TaskCRUDDAO(IDataSource dataSource)
		{
			this._dataSource = dataSource;
		}

		public void Add(TaskDataModel task)
		{
			_dataSource.Add(task);
		}

		public void Update(TaskDataModel task)
		{
			_dataSource.Update(task);
		}

		public void Delete(int taskID)
		{
			_dataSource.Delete(taskID);
		}
	}
}
