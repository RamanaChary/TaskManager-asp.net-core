﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Infrastructure;

namespace XTGlobal.DataAccess.Task
{
	public class TaskVIEWDAO : ITaskVIEWDAO
	{
		private IDataSource _dataSource = null;

		public TaskVIEWDAO(IDataSource dataSource)
		{
			this._dataSource = dataSource;
		}

		public List<TaskDataModel> GetAllTasks()
		{
			return _dataSource.Tasks;
		}

		public List<TaskDataModel> GetCompletedTasks()
		{
			List<TaskDataModel> userTasks = _dataSource.Tasks;

			return userTasks.FindAll(t => t.IsCompleted);
		}

		public List<TaskDataModel> GetOverDueTasks()
		{
			DateTime today = DateTime.UtcNow;

			List<TaskDataModel> userTasks = _dataSource.Tasks;

			return userTasks.FindAll(t => t.DueDate != DateTime.MinValue && t.DueDate.CompareTo(today) < 0);
		}
	}
}
