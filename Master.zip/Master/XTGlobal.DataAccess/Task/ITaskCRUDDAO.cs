﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Task
{
    public interface ITaskCRUDDAO
    {
		void Add(TaskDataModel task);

		void Update(TaskDataModel task);

		void Delete(int taskID);
	}
}
