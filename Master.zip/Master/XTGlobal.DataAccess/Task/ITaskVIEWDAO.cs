﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Task
{
    public interface ITaskVIEWDAO
    {
		List<TaskDataModel> GetAllTasks();
		List<TaskDataModel> GetOverDueTasks();
		List<TaskDataModel> GetCompletedTasks();
	}
}
