﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Task;
using XTGlobal.Common.DTO;

namespace XTGlobal.API.Controllers.Task
{
	/// <summary>
	/// Controller to perform GET/READ operations against Task.
	/// </summary>
	[Produces("application/json")]
    [Route("api/TaskVIEW")]
    public class TaskVIEWController : ControllerBase
    {
		private ITaskVIEWManager _taskVIEWManager = null;
		public TaskVIEWController(ITaskVIEWManager taskVIEWManager)
		{
			this._taskVIEWManager = taskVIEWManager;
		}

		// GET: api/TaskVIEW/GetAll
		[HttpGet("GetAll")]
        public IApiResponse<List<TaskDTO>> GetAll()
        {
			List<TaskDTO> userTasks = null;
			IApiResponse<List<TaskDTO>> apiResponse = new ApiResponse<List<TaskDTO>>();
			try
			{
				userTasks = _taskVIEWManager.GetAllTasks();

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Records = userTasks;
				apiResponse.Count = userTasks.Count();
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
        }

		// GET: api/TaskVIEW/GetOverDue
		[HttpGet("GetOverDue")]
        public IApiResponse<List<TaskDTO>> GetOverDue()
        {
			List<TaskDTO> userTasks = null;
			IApiResponse<List<TaskDTO>> apiResponse = new ApiResponse<List<TaskDTO>>();
			try
			{
				userTasks = _taskVIEWManager.GetOverDueTasks();

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Records = userTasks;
				apiResponse.Count = userTasks.Count();
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		// GET: api/TaskVIEW/GetCompleted
		[HttpGet("GetCompleted")]
		public IApiResponse<List<TaskDTO>> GetCompleted()
		{
			List<TaskDTO> userTasks = null;
			IApiResponse<List<TaskDTO>> apiResponse = new ApiResponse<List<TaskDTO>>();
			try
			{
				userTasks = _taskVIEWManager.GetCompletedTasks();

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Records = userTasks;
				apiResponse.Count = userTasks.Count();
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}
    }
}
