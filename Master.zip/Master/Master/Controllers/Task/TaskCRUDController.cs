﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Task;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Task;

namespace XTGlobal.API.Controllers.Task
{
	/// <summary>
	/// Controller to perform CRUD/WRITE operations against Task.
	/// </summary>
	[Produces("application/json")]
    [Route("api/TaskCRUD")]
    public class TaskCRUDController : ControllerBase
	{
		private ITaskCRUDManager _taskCRUDManager = null;
		public TaskCRUDController(ITaskCRUDManager taskCRUDManager)
		{
			this._taskCRUDManager = taskCRUDManager;
		}
		
        // POST: api/TaskCRUD
        [HttpPost]
        public IApiResponse Post([FromBody] TaskDTO userTask)
        {
			IApiResponse apiResponse = new ApiResponse(); 
			try
			{
				_taskCRUDManager.Add(userTask);

				apiResponse.MessageID = HttpStatusCode.Created;
				apiResponse.MessageText = "Created";
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
        }
        
        // PUT: api/TaskCRUD/5
        [HttpPut]
        public IApiResponse Put([FromBody] TaskDTO userTask)
        {
			IApiResponse apiResponse = new ApiResponse();
			try
			{
				_taskCRUDManager.Update(userTask);

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
        }
        
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IApiResponse Delete(int taskID)
        {
			IApiResponse apiResponse = new ApiResponse();
			try
			{
				_taskCRUDManager.Delete(taskID);

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}
    }
}
