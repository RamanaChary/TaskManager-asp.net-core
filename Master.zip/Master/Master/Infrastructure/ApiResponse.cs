﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace XTGlobal.API.Infrastructure
{
	public class ApiResponse<T> : IApiResponse<T> where T : class
	{
		public HttpStatusCode MessageID { get; set; }
		public string MessageText { get; set; }
		public T Records { get; set; }
		public int Count { get; set; }
	}

	public class ApiResponse : IApiResponse
	{
		public HttpStatusCode MessageID { get; set; }
		public string MessageText { get; set; }
	}
}
