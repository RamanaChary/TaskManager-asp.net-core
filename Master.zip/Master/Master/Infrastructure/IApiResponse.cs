﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace XTGlobal.API.Infrastructure
{
    public interface IApiResponse<T> where T : class
    {
		HttpStatusCode MessageID { get; set; }
		string MessageText { get; set; }
		T Records { get; set; }
		int Count { get; set; }
	}

	public interface IApiResponse
	{
		HttpStatusCode MessageID { get; set; }
		string MessageText { get; set; }
	}
}
