USE master
GO

CREATE DATABASE BLOGDB

USE BLOGDB
GO

--------------------******************--------------------
--Table : User
--Schema : dbo
--Purpose : Holds user information
--------------------******************--------------------
IF NOT EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID('[dbo].[User]') AND OBJECTPROPERTY(id,'IsUserTable') = 1)
BEGIN
CREATE TABLE [User]
(
UserID		 INT IDENTITY(1,1)
,FirstName	 VARCHAR(50)
,LastName	 VARCHAR(50)
)
  
--Add primary key constraint
ALTER TABLE [User]
ADD CONSTRAINT PK_User_UserID PRIMARY KEY CLUSTERED (UserID)
END

--------------------******************--------------------
--Table : Blog
--Schema : dbo
--Purpose : Holds Blog information for each user in a 1-1 mapping
--------------------******************--------------------
IF NOT EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID('[dbo].[Blog]') AND OBJECTPROPERTY(id,'IsUserTable') = 1)
BEGIN
CREATE TABLE Blog
(
BlogID		 INT IDENTITY(1,1)
,Title		 VARCHAR(50)
,UserID		 INT
)
 
--Add primary key constraint
ALTER TABLE Blog
ADD CONSTRAINT PK_Blog_BlogID PRIMARY KEY CLUSTERED (BlogID)

--Add foreign key constraint
ALTER TABLE Blog
ADD CONSTRAINT FK_Blog_UserID FOREIGN KEY (UserID) REFERENCES [User] (UserID)

--Add Unique key constraint for 1-1 relationship
ALTER TABLE Blog
ADD CONSTRAINT UQ_Blog_UserID UNIQUE (UserID)
END

--------------------******************--------------------
--Table : Category
--Schema : dbo
--Purpose : Holds Category master data/seed data
--------------------******************--------------------
IF NOT EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID('[dbo].[Category]') AND OBJECTPROPERTY(id,'IsUserTable') = 1)
BEGIN
CREATE TABLE Category
(
CatID			 INT IDENTITY(1,1)
,Name			 VARCHAR(50)
)
  
--Add primary key constraint
ALTER TABLE Category
ADD CONSTRAINT PK_Category_CatID PRIMARY KEY CLUSTERED (CatID)
END

--------------------******************--------------------
--Table : BlogCategory
--Schema : dbo
--Purpose : Holds category information for each user blog in a 1-M mapping
--------------------******************--------------------
IF NOT EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID('[dbo].[BlogCategory]') AND OBJECTPROPERTY(id,'IsUserTable') = 1)
BEGIN
CREATE TABLE BlogCategory
(
BlgCatID		 INT IDENTITY(1,1)
,BlogID			 INT
,CatID			 INT
)
  
--Add primary key constraint
ALTER TABLE BlogCategory
ADD CONSTRAINT PK_BlogCategory_BlgCatID PRIMARY KEY CLUSTERED (BlgCatID)

--Add foreign key constraint
ALTER TABLE BlogCategory
ADD CONSTRAINT FK_BlogCategory_BlogID FOREIGN KEY (BlogID) REFERENCES Blog (BlogID)

ALTER TABLE BlogCategory
ADD CONSTRAINT FK_BlogCategory_CatID FOREIGN KEY (CatID) REFERENCES Category (CatID)
END

--------------------******************--------------------
--Table : Post
--Schema : dbo
--Purpose : Holds post information
--------------------******************--------------------
IF NOT EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID('[dbo].[Post]') AND OBJECTPROPERTY(id,'IsUserTable') = 1)
BEGIN
CREATE TABLE Post
(
PostID		 INT IDENTITY(1,1)
,[Description] VARCHAR(500)
)
  
--Add primary key constraint
ALTER TABLE Post
ADD CONSTRAINT PK_Post_PostID PRIMARY KEY CLUSTERED (PostID)
END

--------------------******************--------------------
--Table : CategoryPost
--Schema : dbo
--Purpose : Holds posts information for one/more categories in a M-M mapping
--------------------******************--------------------
IF NOT EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID('[dbo].[CategoryPost]') AND OBJECTPROPERTY(id,'IsUserTable') = 1)
BEGIN
CREATE TABLE CategoryPost
(
CatPstID		 INT IDENTITY(1,1)
,PostID			 INT
,CatID			 INT
)
  
--Add primary key constraint
ALTER TABLE CategoryPost
ADD CONSTRAINT PK_CategoryPost_CatPstID PRIMARY KEY CLUSTERED (CatPstID)

--Add foreign key constraint
ALTER TABLE CategoryPost
ADD CONSTRAINT FK_CategoryPost_PostID FOREIGN KEY (PostID) REFERENCES Post (PostID)

ALTER TABLE CategoryPost
ADD CONSTRAINT FK_CategoryPost_CatID FOREIGN KEY (CatID) REFERENCES BlogCategory (CatID)
END

--------------------******************--------------------
--Table : BlogPost
--Schema : dbo
--Purpose : Intermediate table for Post and CategoryPost in a M-M mapping
--------------------******************--------------------
IF NOT EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID('[dbo].[BlogPost]') AND OBJECTPROPERTY(id,'IsUserTable') = 1)
BEGIN
CREATE TABLE BlogPost
(
BlgPstID		 INT IDENTITY(1,1)
,CatPstID		 INT
,BlogID			 INT
)
  
--Add primary key constraint
ALTER TABLE BlogPost
ADD CONSTRAINT PK_BlogPost_BlgPstID PRIMARY KEY CLUSTERED (BlgPstID)

--Add foreign key constraint
ALTER TABLE BlogPost
ADD CONSTRAINT FK_BlogPost_CatPstID FOREIGN KEY (CatPstID) REFERENCES CategoryPost (CatPstID)

ALTER TABLE BlogPost
ADD CONSTRAINT FK_BlogPost_BlogID FOREIGN KEY (BlogID) REFERENCES Blog (BlogID)
END

--------------------******************--------------------
--Insert dummy data and query posts by user
--------------------******************--------------------
INSERT INTO [User](FirstName,LastName)
SELECT 'Ramana' , 'Madupa' UNION
SELECT 'Pradeep' , 'Kumar'

INSERT INTO Blog (Title, UserID)
SELECT 'Ramana Blog', 1 UNION
SELECT 'Pradeep Blog', 2

INSERT INTO Category (Name)
SELECT 'Entertainment' UNION
SELECT 'Politics'

INSERT INTO BlogCategory(BlogID, CatID)
SELECT 2, 2 UNION
SELECT 2,2 UNION
SELECT 2, 2

INSERT INTO Post(Description)
SELECT 'Test post 7' UNION
SELECT 'Test post 8' UNION
SELECT 'Test post 9' 

INSERT INTO CategoryPost (PostID,CatID)
SELECT 4,1 UNION
SELECT 5,1 UNION
SELECT 6,1 UNION
SELECT 4,2 

INSERT INTO BlogPost(CatPstID,BlogID)
SELECT 6,2 UNION
SELECT 7,2 UNION
SELECT 8,2 UNION
SELECT 9,2

SELECT U.UserID,LastName, Title, Name, [Description]
FROM [User] U
JOIN Blog B ON U.UserID = B.UserID
JOIN BlogCategory BC ON B.BlogID = BC.BlogID
JOIN Category C ON BC.CatID = C.CatID
JOIN CategoryPost CP ON C.CatID = CP.CatID
JOIN BlogPost BP ON CP.CatPstID = BP.CatPstID AND BP.BlogID = B.BlogID
JOIN Post P ON CP.PostID = P.PostID