﻿using System;

namespace XTGlobal.DataAccess.Entity.EntityDataModels
{
	public class Task
	{
		public Guid TaskID { get; set; }
		public string Title { get; set; }
		public string Description { get; set; }
		public DateTime DueDate { get; set; }
		public int? UserID { get; set; }
		public bool IsCompleted { get; set; }
	}
}
