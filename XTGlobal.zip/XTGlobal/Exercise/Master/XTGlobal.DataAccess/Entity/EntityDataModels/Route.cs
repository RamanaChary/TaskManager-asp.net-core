﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.DataAccess.Entity.EntityDataModels
{
    public class Route
    {
		public Guid RouteId { get; set; }
		public string RouteTemplate { get; set; }
		public string Method { get; set; }
	}
}
