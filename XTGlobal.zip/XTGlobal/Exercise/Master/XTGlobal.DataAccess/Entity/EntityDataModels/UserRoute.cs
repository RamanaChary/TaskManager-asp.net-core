﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.DataAccess.Entity.EntityDataModels
{
    public class UserRoute
    {
		public string Email { get; set; }
		public Guid RouteId { get; set; }
	}
}
