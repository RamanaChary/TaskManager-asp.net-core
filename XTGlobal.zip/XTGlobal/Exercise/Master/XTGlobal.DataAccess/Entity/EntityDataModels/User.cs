﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.DataAccess.Entity.EntityDataModels
{
    public class User
    {
		public string Email { get; set; }
		public string Password { get; set; }
	}
}
