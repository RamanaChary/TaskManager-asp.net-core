﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Task;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Infrastructure;

namespace XTGlobal.DataAccess.Task
{
	public class TaskVIEWDAO : ITaskVIEWDAO
	{
		private IDataSource _dataSource = null;

		public TaskVIEWDAO(IDataSource dataSource)
		{
			_dataSource = dataSource;
		}

		public PagedList<TaskDataModel> GetAllTasks(TaskResourceParameters parameters)
		{
			var collection = _dataSource.Tasks?.AsQueryable<TaskDataModel>();

			if(!string.IsNullOrWhiteSpace(parameters.Title))
			{
				collection = collection.Where(items => items.Title == parameters.Title);
			}
			if(!string.IsNullOrWhiteSpace(parameters.Description))
			{
				collection = collection.Where(items => items.Description == parameters.Description);
			}

			return PagedList<TaskDataModel>.Create(collection,parameters.PageNumber,parameters.PageSize);
		}

		public TaskDataModel GetTask(Guid taskId)
		{
			return _dataSource.Tasks?.Find(x => x.TaskID == taskId);
		}

		public List<TaskDataModel> GetCompletedTasks()
		{
			return _dataSource.Tasks?.FindAll(t => t.IsCompleted);
		}

		public List<TaskDataModel> GetOverDueTasks(DateTime dueDate)
		{
			return _dataSource.Tasks?.FindAll(t => t.DueDate != DateTime.MinValue && 
									t.DueDate.CompareTo(dueDate) < 0 &&
									!t.IsCompleted);
		}
	}
}
