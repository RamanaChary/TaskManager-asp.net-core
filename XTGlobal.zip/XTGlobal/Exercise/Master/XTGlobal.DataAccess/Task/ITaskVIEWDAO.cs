﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Task;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Task
{
    public interface ITaskVIEWDAO
    {
		PagedList<TaskDataModel> GetAllTasks(TaskResourceParameters parameters);
		TaskDataModel GetTask(Guid taskId);
		List<TaskDataModel> GetOverDueTasks(DateTime dueDate);
		List<TaskDataModel> GetCompletedTasks();
	}
}
