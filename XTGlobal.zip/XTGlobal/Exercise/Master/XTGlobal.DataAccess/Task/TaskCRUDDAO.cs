﻿using System;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Infrastructure;

namespace XTGlobal.DataAccess.Task
{
	public class TaskCRUDDAO : ITaskCRUDDAO
	{
		private IDataSource _dataSource = null;

		public TaskCRUDDAO(IDataSource dataSource)
		{
			this._dataSource = dataSource ??
				throw new ArgumentNullException(nameof(dataSource)); ;
		}

		public void Add(TaskDataModel task)
		{
			_dataSource.Add(task);
		}

		public void Update(TaskDataModel task)
		{
			_dataSource.Update(task);
		}

		public void Delete(Guid taskID)
		{
			_dataSource.Delete(taskID);
		}

		public TaskDataModel TaskExists(Guid taskId)
		{
			return _dataSource.Tasks.Find(x => x.TaskID == taskId);
		}
	}
}
