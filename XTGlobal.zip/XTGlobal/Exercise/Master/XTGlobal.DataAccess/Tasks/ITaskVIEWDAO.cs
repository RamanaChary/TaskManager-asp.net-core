﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Tasks
{
    public interface ITaskVIEWDAO
    {
		PagedList<Task> GetAllTasks(TaskResourceParameters parameters);
		Task GetTask(Guid taskId);
		PagedList<Task> GetOverDueTasks(DateTime dueDate, TaskResourceParameters parameters);
		PagedList<Task> GetCompletedTasks(TaskResourceParameters parameters);
	}
}
