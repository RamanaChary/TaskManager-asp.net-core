﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Tasks
{
    public interface ITaskCRUDDAO
    {
		void Add(Entity.EntityDataModels.Task task);

		void Update(Entity.EntityDataModels.Task task);

		void Delete(Guid taskID);

		Task TaskExists(Guid taskId);
	}
}
