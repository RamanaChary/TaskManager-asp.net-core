﻿using System;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Tasks
{
	public interface ITaskCRUDDAO
    {
		Guid Add(Task task);

		void Update(Task task);

		void Delete(Guid taskID);

		Task TaskExists(Guid taskId);
	}
}
