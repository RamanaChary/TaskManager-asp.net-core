﻿using System;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Infrastructure;

namespace XTGlobal.DataAccess.Tasks
{
	public class TaskCRUDDAO : ITaskCRUDDAO
	{
		private IDataSource _dataSource;

		public TaskCRUDDAO(IDataSource dataSource)
		{
			this._dataSource = dataSource;
		}

		public Guid Add(Task task)
		{
			return _dataSource.Add(task);
		}

		public void Update(Task task)
		{
			_dataSource.Update(task);
		}

		public void Delete(Guid taskID)
		{
			_dataSource.Delete(taskID);
		}

		public Task TaskExists(Guid taskId)
		{
			return _dataSource.Tasks.Find(x => x.TaskID == taskId);
		}
	}
}
