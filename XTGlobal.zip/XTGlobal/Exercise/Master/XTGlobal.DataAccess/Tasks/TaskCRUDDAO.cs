﻿using System;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Infrastructure;

namespace XTGlobal.DataAccess.Tasks
{
	public class TaskCRUDDAO : ITaskCRUDDAO
	{
		private IDataSource _dataSource = null;

		public TaskCRUDDAO(IDataSource dataSource)
		{
			this._dataSource = dataSource ??
				throw new ArgumentNullException(nameof(dataSource)); ;
		}

		public void Add(Entity.EntityDataModels.Task task)
		{
			_dataSource.Add(task);
		}

		public void Update(Entity.EntityDataModels.Task task)
		{
			_dataSource.Update(task);
		}

		public void Delete(Guid taskID)
		{
			_dataSource.Delete(taskID);
		}

		public Task TaskExists(Guid taskId)
		{
			return _dataSource.Tasks.Find(x => x.TaskID == taskId);
		}
	}
}
