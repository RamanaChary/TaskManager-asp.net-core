﻿using System;
using System.Linq;
using XTGlobal.Common.DTO.User;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Infrastructure;

namespace XTGlobal.DataAccess.Authentication
{
	public class AuthCRUDDAO : IAuthCRUDDAO
	{
		private IDataSource _dataSource;

		public AuthCRUDDAO(IDataSource dataSource)
		{
			_dataSource = dataSource;
		}

		public User LogIn(UserDto loginDto)
		{
			return _dataSource.Users.Where(user => user.Email.Equals(loginDto.Email) && user.Password.Equals(loginDto.Password))?.FirstOrDefault();
		}

		public bool ValidateRoute(string email, string routeTemplate, string method)
		{
			var result = (from user in _dataSource.Users
						  join userRoute in _dataSource.UserRoutes on user.Email equals userRoute.Email
						  join route in _dataSource.Routes on userRoute.RouteId equals route.RouteId
						  where user.Email.Equals(email) &&
						  route.RouteTemplate.Equals(routeTemplate) &&
						  route.Method.Equals(method)
						  select user
						 ).FirstOrDefault();
			if (result != null)
				return true;
			else
				return false;
		}
	}
}
