﻿using System;
using System.Linq;
using XTGlobal.Common.DTO.User;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Infrastructure;

namespace XTGlobal.DataAccess.Authentication
{
	public class AuthCRUDDAO : IAuthCRUDDAO
	{
		private IDataSource _dataSource = null;

		public AuthCRUDDAO(IDataSource dataSource)
		{
			this._dataSource = dataSource ??
				throw new ArgumentNullException(nameof(dataSource)); ;
		}

		public User LogIn(UserDto loginDto)
		{
			return _dataSource.Users.Where(user => user.Email.Equals(loginDto.Email) && user.Password.Equals(loginDto.Password))?.FirstOrDefault();
		}
	}
}
