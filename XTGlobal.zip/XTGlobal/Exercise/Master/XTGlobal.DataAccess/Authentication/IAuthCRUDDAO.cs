﻿using XTGlobal.Common.DTO.User;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Authentication
{
	public interface IAuthCRUDDAO
    {
		User LogIn(UserDto loginDto);
	}
}
