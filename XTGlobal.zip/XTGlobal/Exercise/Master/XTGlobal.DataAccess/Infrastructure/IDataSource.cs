﻿using System;
using System.Collections.Generic;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Infrastructure
{
	public interface IDataSource
    {
		Guid Add(Task task);

		void Update(Task task);

		void Delete(Guid taskID);

		List<Task> Tasks { get; }

		List<User> Users { get; }
	}
}
