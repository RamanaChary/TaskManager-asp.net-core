﻿using System;
using System.Collections.Generic;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Infrastructure
{
	public interface IDataSource
    {
		void Add(Entity.EntityDataModels.Task task);

		void Update(Entity.EntityDataModels.Task task);

		void Delete(Guid taskID);

		List<Entity.EntityDataModels.Task> Tasks { get; }

		List<User> Users { get; }
	}
}
