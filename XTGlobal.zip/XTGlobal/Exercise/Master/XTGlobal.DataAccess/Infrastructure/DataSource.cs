﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Infrastructure
{
	/// <summary>
	/// In memory data source
	/// This should be replaced by a DBContext/Repository
	/// </summary>
	public class DataSource : IDataSource
	{
		private static List<Entity.EntityDataModels.Task> userTasks = new List<Entity.EntityDataModels.Task>();
		private static List<User> users = new List<User>();

		static DataSource()
		{
			users.AddRange(new List<User>()
			{
				new User()
				{
					Email = "mchary@deloitte.com",
					Password = "Admin"
				},
				new User()
				{
					Email = "rmadupa@deloitte.com",
					Password = "Admin"
				}
			});
			userTasks.AddRange(new List<Entity.EntityDataModels.Task>()
			{
				new Entity.EntityDataModels.Task()	{
					TaskID = Guid.NewGuid(),
					Title = "Task1Title",
					Description = "Task1Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Entity.EntityDataModels.Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task2Title",
					Description = "Task2Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Entity.EntityDataModels.Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task3Title",
					Description = "Task3Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Entity.EntityDataModels.Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task4Title",
					Description = "Task4Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Entity.EntityDataModels.Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task5Title",
					Description = "Task5Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Entity.EntityDataModels.Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task6Title",
					Description = "Task6Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Entity.EntityDataModels.Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task7Title",
					Description = "Task7Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Entity.EntityDataModels.Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task8Title",
					Description = "Task8Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Entity.EntityDataModels.Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task9Title",
					Description = "Task9Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Entity.EntityDataModels.Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task10Title",
					Description = "Task10Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				}
			}
				);
		}

		public void Add(Entity.EntityDataModels.Task task)
		{
			task.TaskID = Guid.NewGuid();
			userTasks.Add(task);
		}

		public void Update(Entity.EntityDataModels.Task task)
		{
			Entity.EntityDataModels.Task tempTask = userTasks.Find(t => t.TaskID == task.TaskID);

			if (tempTask != null)
			{
				tempTask.Title = task.Title;
				tempTask.Description = task.Description;
				tempTask.DueDate = task.DueDate;
				tempTask.IsCompleted = task.IsCompleted;
				tempTask.UserID = task.UserID;
			}
		}

		public void Delete(Guid taskID)
		{
			Entity.EntityDataModels.Task tempTask = userTasks.Find(t => t.TaskID == taskID);

			if (tempTask != null)
			{
				userTasks.Remove(tempTask);
			}
		}

		public List<Entity.EntityDataModels.Task> Tasks => userTasks;
		public List<User> Users => users;
	}
}
