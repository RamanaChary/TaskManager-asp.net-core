﻿using System;
using System.Collections.Generic;
using System.Linq;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Infrastructure
{
	/// <summary>
	/// In memory data source
	/// This should be replaced by a DBContext/Repository
	/// </summary>
	public class DataSource : IDataSource
	{
		private static List<Task> userTasks = new List<Task>();
		private static List<User> users = new List<User>();
		private static List<Route> routes = new List<Route>();

		static DataSource()
		{
			users.AddRange(new List<User>()
			{
				new User()
				{
					Email = "mchary@deloitte.com",
					Password = "Admin"
				},
				new User()
				{
					Email = "rmadupa@deloitte.com",
					Password = "Admin"
				}
			});
			routes.AddRange(new List<Route>()
			{
				new Route()
				{
					RouteId = Guid.NewGuid(),
					RouteTemplate = "api/TaskVIEW/Tasks",
					Method = "GET"
				},
				new Route()
				{
					RouteId = Guid.NewGuid(),
					RouteTemplate = "api/TaskVIEW/Tasks/{taskId}",
					Method = "GET"
				},
				new Route()
				{
					RouteId = Guid.NewGuid(),
					RouteTemplate = "api/TaskVIEW/Tasks/OverDue",
					Method = "GET"
				},
				new Route()
				{
					RouteId = Guid.NewGuid(),
					RouteTemplate = "api/TaskVIEW/Tasks/Completed",
					Method = "GET"
				},
				new Route()
				{
					RouteId = Guid.NewGuid(),
					RouteTemplate = "api/TaskCRUD/Tasks",
					Method = "POST"
				},
				new Route()
				{
					RouteId = Guid.NewGuid(),
					RouteTemplate = "api/TaskCRUD/Tasks/{taskId}",
					Method = "PUT"
				},
				new Route()
				{
					RouteId = Guid.NewGuid(),
					RouteTemplate = "api/TaskCRUD/Tasks/{taskId}",
					Method = "PATCH"
				},
				new Route()
				{
					RouteId = Guid.NewGuid(),
					RouteTemplate = "api/TaskCRUD/Tasks/{taskId}",
					Method = "DELETE"
				}
			});
			userTasks.AddRange(new List<Task>()
			{
				new Task()	{
					TaskID = Guid.NewGuid(),
					Title = "Task1Title",
					Description = "Task1Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task2Title",
					Description = "Task2Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task3Title",
					Description = "Task3Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task4Title",
					Description = "Task4Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task5Title",
					Description = "Task5Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task6Title",
					Description = "Task6Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task7Title",
					Description = "Task7Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task8Title",
					Description = "Task8Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task9Title",
					Description = "Task9Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task10Title",
					Description = "Task10Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				}
			}
				);
		}

		public Guid Add(Task task)
		{
			task.TaskID = Guid.NewGuid();
			userTasks.Add(task);

			return task.TaskID;
		}

		public void Update(Task task)
		{
			Task tempTask = userTasks.Find(t => t.TaskID == task.TaskID);

			if (tempTask != null)
			{
				tempTask.Title = task.Title;
				tempTask.Description = task.Description;
				tempTask.DueDate = task.DueDate;
				tempTask.IsCompleted = task.IsCompleted;
				tempTask.UserID = task.UserID;
			}
		}

		public void Delete(Guid taskID)
		{
			Task tempTask = userTasks.Find(t => t.TaskID == taskID);

			if (tempTask != null)
			{
				userTasks.Remove(tempTask);
			}
		}

		public List<Task> Tasks => userTasks;
		public List<User> Users => users;
		public List<UserRoute> UserRoutes => GetUserRoutes();
		public List<Route> Routes => routes;

		private static List<UserRoute> GetUserRoutes()
		{
			List<UserRoute> userRoutes = new List<UserRoute>();
			string email = users.Where(x => x.Email.Equals("mchary@deloitte.com")).FirstOrDefault().Email;

			foreach (var route in routes)
			{
				userRoutes.Add(new UserRoute() { Email = email, RouteId = route.RouteId });
			}

			email = users.Where(x => x.Email.Equals("rmadupa@deloitte.com")).FirstOrDefault().Email;
			foreach (var route in routes)
			{
				if (route.Method.Equals("GET"))
					userRoutes.Add(new UserRoute() { Email = email, RouteId = route.RouteId });
			}

			return userRoutes;
		}
	}
}
