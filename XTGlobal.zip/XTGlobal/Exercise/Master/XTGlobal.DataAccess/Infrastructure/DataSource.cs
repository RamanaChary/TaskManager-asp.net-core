﻿using System;
using System.Collections.Generic;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.DataAccess.Infrastructure
{
	/// <summary>
	/// In memory data source
	/// This should be replaced by a DBContext/Repository
	/// </summary>
	public class DataSource : IDataSource
	{
		private static List<Task> userTasks = new List<Task>();
		private static List<User> users = new List<User>();

		static DataSource()
		{
			users.AddRange(new List<User>()
			{
				new User()
				{
					Email = "mchary@deloitte.com",
					Password = "Admin"
				},
				new User()
				{
					Email = "rmadupa@deloitte.com",
					Password = "Admin"
				}
			});
			userTasks.AddRange(new List<Task>()
			{
				new Task()	{
					TaskID = Guid.NewGuid(),
					Title = "Task1Title",
					Description = "Task1Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task2Title",
					Description = "Task2Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task3Title",
					Description = "Task3Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task4Title",
					Description = "Task4Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task5Title",
					Description = "Task5Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task6Title",
					Description = "Task6Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task7Title",
					Description = "Task7Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task8Title",
					Description = "Task8Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task9Title",
					Description = "Task9Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				},
				new Task()
				{
					TaskID = Guid.NewGuid(),
					Title = "Task10Title",
					Description = "Task10Description",
					DueDate = DateTime.Now,
					UserID = 1,
					IsCompleted = false
				}
			}
				);
		}

		public Guid Add(Task task)
		{
			task.TaskID = Guid.NewGuid();
			userTasks.Add(task);

			return task.TaskID;
		}

		public void Update(Task task)
		{
			Task tempTask = userTasks.Find(t => t.TaskID == task.TaskID);

			if (tempTask != null)
			{
				tempTask.Title = task.Title;
				tempTask.Description = task.Description;
				tempTask.DueDate = task.DueDate;
				tempTask.IsCompleted = task.IsCompleted;
				tempTask.UserID = task.UserID;
			}
		}

		public void Delete(Guid taskID)
		{
			Task tempTask = userTasks.Find(t => t.TaskID == taskID);

			if (tempTask != null)
			{
				userTasks.Remove(tempTask);
			}
		}

		public List<Task> Tasks => userTasks;
		public List<User> Users => users;
	}
}
