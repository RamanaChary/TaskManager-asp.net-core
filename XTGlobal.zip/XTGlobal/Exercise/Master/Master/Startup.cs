﻿using AutoMapper;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Swagger;
using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.API.Infrastructure;
using XTGlobal.API.Profiles;
using XTGlobal.BusinessLogic.Infrastructure;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;

namespace Master
{
	public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
			var appSettings = new AppSettings();
			Configuration.Bind(nameof(appSettings), appSettings);
			services.AddSingleton(appSettings);

			if(appSettings.UseCaching)
			{
				services.AddHttpCacheHeaders((expirationModelOptions) =>
				{
					expirationModelOptions.MaxAge = 600;
					expirationModelOptions.CacheLocation = Marvin.Cache.Headers.CacheLocation.Public;
				},
				(validationModelOptions) =>
				{
					validationModelOptions.MustRevalidate = true;
				}
				);

				services.AddResponseCaching();
			}
			

			services.AddMvc()
				.AddJsonOptions(options =>
				{
					options.SerializerSettings.Formatting = Formatting.Indented;
				})
				.AddFluentValidation();

			if(appSettings.UseJwtAuthentication)
			{
				services.AddAuthentication(authOptions =>
				{
					authOptions.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
					authOptions.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
					authOptions.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
				}).AddJwtBearer(jwt =>
				{
					jwt.RequireHttpsMetadata = false;
					jwt.SaveToken = true;
					jwt.TokenValidationParameters = new TokenValidationParameters()
					{
						ValidateIssuerSigningKey = true,
						//ValidIssuer = "",
						ValidateIssuer = false,
						//ValidAudience = "",
						ValidateAudience = false,
						ValidateLifetime = true,
						RequireExpirationTime = true,
						IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(appSettings.JwtSecret))
					};
				});
			}
			
			// Register the Swagger generator, defining 1 or more Swagger documents
			services.AddSwaggerGen(c =>
			{
				c.SwaggerDoc("v1", new Info { Title = "Task management API", Version = "v1" });

				if(appSettings.UseJwtAuthentication)
				{
					var security = new Dictionary<string, IEnumerable<string>>()
				{
					{ "Bearer",new string[0] }
				};

					c.AddSecurityDefinition("Bearer", new ApiKeyScheme()
					{
						Description = "Please enter into field the word 'bearer' following by space and JWT token",
						Name = "Authorization",
						In = "header",
						Type = "apiKey"
					});

					c.AddSecurityRequirement(security);
				}				
			});

			////Inject application dependencies
			services.AddApiDependency();
			services.AddLogicDependency();
			

			// Auto Mapper Configurations
			var mappingConfig = new MapperConfiguration(mc =>
			{
				mc.AddProfile(new TaskProfile());
				mc.AddProfile(new UserProfile());
				mc.AddProfile(new MappingProfile());
			});

			IMapper mapper = mappingConfig.CreateMapper();
			services.AddSingleton(mapper);

		}

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, AppSettings appSettings)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

				app.UseSwagger();
				// specifying the Swagger JSON endpoint.
				app.UseSwaggerUI(c =>
				{
					c.SwaggerEndpoint("/swagger/v1/swagger.json", "Task management API v1");
				});
			}

			//app.ApplyUserKeyValidation();

			//if (appSettings.UseCaching)
			//{
			//	app.UseResponseCaching();
			//	app.Use(async (context, next) =>
			//	{
			//		context.Response.GetTypedHeaders().CacheControl =
			//			new Microsoft.Net.Http.Headers.CacheControlHeaderValue()
			//			{
			//				Public = true,
			//				MaxAge = TimeSpan.FromSeconds(600),
			//				MustRevalidate = true
			//			};
			//		context.Response.Headers[Microsoft.Net.Http.Headers.HeaderNames.Vary] =
			//			new string[] { "Accept-Encoding" };

			//		await next();
			//	});
			//}


			if (appSettings.UseCaching)
				app.UseHttpCacheHeaders();

			if (appSettings.UseJwtAuthentication)
				app.UseAuthentication();

			app.UseMvc(routes =>
			{
				routes.MapRoute("default", "{controller=Home}/{action=Index}/{id?}");
			});
		}
    }
}
