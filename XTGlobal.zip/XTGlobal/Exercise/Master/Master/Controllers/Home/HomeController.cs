﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace XTGlobal.API.Controllers.Home
{
	[Route("api/Home")]
	public class HomeController : ControllerBase
	{
		[HttpGet]
		public ActionResult Index()
		{
			return Ok("Welcome to Asp.Net Core Api...");
		}
	}
}