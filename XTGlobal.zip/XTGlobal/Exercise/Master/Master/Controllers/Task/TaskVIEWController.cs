﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Marvin.Cache.Headers;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Task;
using XTGlobal.Common.DTO.Task;

namespace XTGlobal.API.Controllers.Task
{
	/// <summary>
	/// Controller to perform GET/READ operations against Task.
	/// </summary>
    [Route("api/TaskVIEW/Tasks")]
	[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
	public class TaskVIEWController : ControllerBase
	{
		private ITaskVIEWManager _taskVIEWManager = null;

		public TaskVIEWController(ITaskVIEWManager taskVIEWManager)
		{
			_taskVIEWManager = taskVIEWManager ??
				throw new ArgumentNullException(nameof(taskVIEWManager));
		}

		[HttpGet]
		[Route("")]
        public IApiResponse<List<TaskDto>> GetAllTasks([FromQuery] TaskResourceParameters parameters)
        {
			IApiResponse<List<TaskDto>> apiResponse = new ApiResponse<List<TaskDto>>();
			parameters = parameters ?? new TaskResourceParameters();
			try
			{
				var userTasks = _taskVIEWManager.GetAllTasks(parameters);

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Records = userTasks;
				apiResponse.Count = userTasks?.Count() ?? 0;
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
        }

		[HttpGet]
		[Route("{taskId}")]
		public IApiResponse<TaskDto> GetTaskByTaskId(Guid taskId)
		{
			IApiResponse<TaskDto> apiResponse = new ApiResponse<TaskDto>();
			try
			{
				var userTask = _taskVIEWManager.GetTask(taskId);

				if (userTask == null)
				{
					apiResponse.MessageID = HttpStatusCode.NotFound;
					apiResponse.MessageText = "NotFound";

					return apiResponse;
				}

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Records = userTask;
				apiResponse.Count = 1;
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		[HttpGet]
		[Route("OverDue")]
		public IApiResponse<List<TaskDto>> GetOverDueTasks([FromQuery] string dueDate)
		{
			DateTime overDueDate = string.IsNullOrWhiteSpace(dueDate) ? DateTime.UtcNow : Convert.ToDateTime(dueDate);
			IApiResponse<List<TaskDto>> apiResponse = new ApiResponse<List<TaskDto>>();
			try
			{
				var userTasks = _taskVIEWManager.GetOverDueTasks(overDueDate);

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Records = userTasks;
				apiResponse.Count = userTasks?.Count() ?? 0;
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		[HttpGet]
		[Route("Completed")]
		public IApiResponse<List<TaskDto>> GetCompletedTasks()
		{
			IApiResponse<List<TaskDto>> apiResponse = new ApiResponse<List<TaskDto>>();
			try
			{
				var userTasks = _taskVIEWManager.GetCompletedTasks();

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Records = userTasks;
				apiResponse.Count = userTasks?.Count() ?? 0;
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}
	}
}
