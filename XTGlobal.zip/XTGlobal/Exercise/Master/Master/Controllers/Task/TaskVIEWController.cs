﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Marvin.Cache.Headers;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Task;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Task;

namespace XTGlobal.API.Controllers.Task
{
	/// <summary>
	/// Controller to perform GET/READ operations against Task.
	/// </summary>
	[Route("api/TaskVIEW/Tasks")]
	[HttpCacheExpiration(CacheLocation = CacheLocation.Public, MaxAge = 600)]
	[HttpCacheValidation(MustRevalidate = true)]
	public class TaskVIEWController : BaseController
	{
		private ITaskVIEWManager _taskVIEWManager = null;
		private AppSettings _appSettings = null;

		public TaskVIEWController(ITaskVIEWManager taskVIEWManager, AppSettings appSettings)
		{
			_taskVIEWManager = taskVIEWManager ??
				throw new ArgumentNullException(nameof(taskVIEWManager));
			_appSettings = appSettings ??
				throw new ArgumentNullException(nameof(appSettings));
		}

		[HttpGet]
		[Route("",Name = "GetAllTasks")]
        public IApiCollectionResponse<TaskDto> GetAllTasks([FromQuery] TaskResourceParameters parameters)
        {
			IApiCollectionResponse<TaskDto> apiResponse = new ApiCollectionResponse<TaskDto>();
			parameters = parameters ?? new TaskResourceParameters();
			try
			{
				var userTasks = _taskVIEWManager.GetAllTasks(parameters);

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Result = CreateResourceCollection(userTasks, "GetAllTasks", "GetTaskByTaskId", null);
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
        }

		[HttpGet]
		[Route("{taskId}", Name = "GetTaskByTaskId")]
		public IApiResponse<TaskDto> GetTaskByTaskId([FromRoute] Guid taskId)
		{
			IApiResponse<TaskDto> apiResponse = new ApiResponse<TaskDto>();
			try
			{
				var userTask = _taskVIEWManager.GetTask(taskId);

				if (userTask == null)
				{
					apiResponse.MessageID = HttpStatusCode.NotFound;
					apiResponse.MessageText = "NotFound";

					return apiResponse;
				}

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Result = CreateResource(userTask, "GetTaskByTaskId");
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		[HttpGet]
		[Route("OverDue", Name = "GetOverDueTasks")]
		public IApiCollectionResponse<TaskDto> GetOverDueTasks([FromQuery] string dueDate)
		{
			DateTime overDueDate = string.IsNullOrWhiteSpace(dueDate) ? DateTime.UtcNow : Convert.ToDateTime(dueDate);
			IApiCollectionResponse<TaskDto> apiResponse = new ApiCollectionResponse<TaskDto>();
			try
			{
				var userTasks = _taskVIEWManager.GetOverDueTasks(overDueDate);

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Result = CreateResourceCollection(userTasks, "GetOverDueTasks", "GetTaskByTaskId", null);
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		[HttpGet]
		[Route("Completed", Name = "GetCompletedTasks")]
		public IApiCollectionResponse<TaskDto> GetCompletedTasks()
		{
			IApiCollectionResponse<TaskDto> apiResponse = new ApiCollectionResponse<TaskDto>();
			try
			{
				var userTasks = _taskVIEWManager.GetCompletedTasks();

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Result = CreateResourceCollection(userTasks, "GetCompletedTasks", "GetTaskByTaskId", null);
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		private CollectionResource<TaskDto> CreateResourceCollection(List<TaskDto> userTasks, string parentActionName, string childActionName, string fields)
		{
			var colletionResource = new CollectionResource<TaskDto>();

			if (userTasks != null && userTasks.Count() > 0)
			{
				userTasks.ForEach(x =>
				{
					colletionResource.Records.Add(new Resource<TaskDto>(x));
				});
			}

			if (_appSettings.CreateHypermediaLinks)
			{
				if (colletionResource != null && colletionResource.Records.Count() > 0)
				{
					colletionResource.Records.ForEach(x =>
					{
						x.Links = GenerateResourceLinks(childActionName, x.Record.TaskID);
					});

					colletionResource.PageLinks = GeneratePageLinks(parentActionName, fields);
				}

			}

			return colletionResource;
		}

		private Resource<TaskDto> CreateResource(TaskDto userTask, string actionName)
		{
			var resource = new Resource<TaskDto>(userTask);

			if (_appSettings.CreateHypermediaLinks)
			{
				if (resource != null)
				{
					resource.Links = GenerateResourceLinks(actionName, resource.Record.TaskID);
				}

			}

			return resource;
		}

		private List<Link> GenerateResourceLinks(string actionName, Guid taskId)
		{
			var links = new List<Link>();

			links.Add(new Link(Url.Link(actionName, new { taskId }), "Self", "GET"));
			links.Add(new Link(Url.Link("CreateTask", null), "create_task", "POST"));
			links.Add(new Link(Url.Link("UpdateTask", new { taskId }), "update_task", "PUT"));
			links.Add(new Link(Url.Link("UpdatePartialTask", new { taskId }), "update_partial_task", "PATCH"));
			links.Add(new Link(Url.Link("DeleteTask", new { taskId }), "delete_task", "DELETE"));

			return links;
		}

		private List<PageLink> GeneratePageLinks(string actionName, string fields)
		{
			var pageLinks = new List<PageLink>();

			pageLinks.Add(new PageLink(Url.Link(actionName, new { fields }), "Self", "GET"));

			return pageLinks;
		}
	}
}
