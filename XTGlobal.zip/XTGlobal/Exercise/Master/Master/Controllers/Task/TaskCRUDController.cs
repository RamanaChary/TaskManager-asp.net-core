﻿using System;
using System.Net;
using AutoMapper;
using FluentValidation;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.ApiModels.Task.Create;
using XTGlobal.API.ApiModels.Task.Update;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Task;
using XTGlobal.Common.DTO.Task;

namespace XTGlobal.API.Controllers.Task
{
	/// <summary>
	/// Controller to perform CRUD/WRITE operations against Task.
	/// </summary>
	[Route("api/TaskCRUD/Tasks")]
	public class TaskCRUDController : BaseController
	{
		private ITaskCRUDManager _taskCRUDManager = null;
		private IMapper _mapper = null;
		private IValidator<TaskForUpdateDto> _taskForUpdateDtovalidator = null;
		private IValidator<TaskForCreationDto> _taskForCreationDtovalidator = null;

		public TaskCRUDController(ITaskCRUDManager taskCRUDManager, IMapper mapper)
		{
			_taskCRUDManager = taskCRUDManager ??
				throw new ArgumentNullException(nameof(taskCRUDManager));
			_mapper = mapper ??
				throw new ArgumentNullException(nameof(mapper));
		}

		[HttpPost]
		[Route("",Name = "CreateTask")]
		public IApiResponse Post([FromBody] TaskForCreationDto userTask, [FromServices] IValidator<TaskForCreationDto> taskForCreationDtovalidator)
		{
			_taskForCreationDtovalidator = taskForCreationDtovalidator ??
				throw new ArgumentNullException(nameof(taskForCreationDtovalidator));

			IApiResponse apiResponse = new ApiResponse();
			try
			{
				var validationResult = _taskForCreationDtovalidator.Validate(userTask);

				if(!validationResult.IsValid)
				{
					apiResponse.MessageID = HttpStatusCode.BadRequest;
					apiResponse.MessageText = "BadRequest";
					apiResponse.Errors = validationResult.Errors?.AddToValidationStatus();

					return apiResponse;
				}

				var taskForCreation = _mapper.Map<TaskDto>(userTask);

				_taskCRUDManager.Add(taskForCreation);

				apiResponse.MessageID = HttpStatusCode.Created;
				apiResponse.MessageText = "Created";
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		[HttpPut]
		[Route("{taskId}", Name = "UpdateTask")]
		public IApiResponse Put([FromBody] TaskForUpdateDto userTask, Guid taskId, [FromServices] IValidator<TaskForUpdateDto> validator)
        {
			_taskForUpdateDtovalidator = validator ??
				throw new ArgumentNullException(nameof(validator));

			IApiResponse apiResponse = new ApiResponse();
			try
			{
				var validationResult = _taskForUpdateDtovalidator.Validate(userTask);

				if (!validationResult.IsValid)
				{
					apiResponse.MessageID = HttpStatusCode.BadRequest;
					apiResponse.MessageText = "BadRequest";
					apiResponse.Errors = validationResult.Errors?.AddToValidationStatus();

					return apiResponse;
				}

				var existingTask = _taskCRUDManager.TaskExists(taskId);

				if(existingTask == null)
				{
					apiResponse.MessageID = HttpStatusCode.NotFound;
					apiResponse.MessageText = "NotFound";

					return apiResponse;
				}

				var taskForUpdate = _mapper.Map(userTask, existingTask);
				_taskCRUDManager.Update(taskForUpdate);

				apiResponse.MessageID = HttpStatusCode.NoContent;
				apiResponse.MessageText = "NoContent";
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
        }

		[HttpPatch]
		[Route("{taskId}", Name = "UpdatePartialTask")]
		public IApiResponse Patch([FromBody] JsonPatchDocument<TaskForUpdateDto> patchDocument, Guid taskId, [FromServices] IValidator<TaskForUpdateDto> validator)
		{
			_taskForUpdateDtovalidator = validator ??
				throw new ArgumentNullException(nameof(validator));

			IApiResponse apiResponse = new ApiResponse();
			try
			{
				//Step 1. Get the task by taskId
				var existingTask = _taskCRUDManager.TaskExists(taskId);

				if(existingTask == null)
				{
					apiResponse.MessageID = HttpStatusCode.NotFound;
					apiResponse.MessageText = "NotFound";

					return apiResponse;
				}

				//Step 2. Map the existing task to TaskForUpdateDto
				var taskToPatch = _mapper.Map<TaskForUpdateDto>(existingTask);

				//Step 3. Apply changes from JsonPatchDocument to the above dto
				patchDocument.ApplyTo(taskToPatch);

				//Step 4. validate the taskToPatch
				var validationResult = _taskForUpdateDtovalidator.Validate(taskToPatch);

				if (!validationResult.IsValid)
				{
					apiResponse.MessageID = HttpStatusCode.BadRequest;
					apiResponse.MessageText = "BadRequest";
					apiResponse.Errors = validationResult.Errors?.AddToValidationStatus();

					return apiResponse;
				}

				//Step 5. Map the patched TaskForUpdateDto to TaskDto inorder for update to db
				var taskForUpdate = _mapper.Map(taskToPatch, existingTask);

				//Step 6. Commit changes to db
				_taskCRUDManager.Update(taskForUpdate);

				apiResponse.MessageID = HttpStatusCode.NoContent;
				apiResponse.MessageText = "NoContent";
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}
        
        [HttpDelete]
		[Route("{taskId}", Name = "DeleteTask")]
		public IApiResponse Delete(Guid taskId)
        {
			IApiResponse apiResponse = new ApiResponse();
			try
			{
				var existingTask = _taskCRUDManager.TaskExists(taskId);

				if (existingTask == null)
				{
					apiResponse.MessageID = HttpStatusCode.NotFound;
					apiResponse.MessageText = "NotFound";

					return apiResponse;
				}

				_taskCRUDManager.Delete(taskId);

				apiResponse.MessageID = HttpStatusCode.NoContent;
				apiResponse.MessageText = "NoContent";
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}
    }
}
