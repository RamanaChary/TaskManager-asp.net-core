﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using XTGlobal.API.ApiModels.Athentication.Login;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Athentication;
using XTGlobal.Common.DTO.Athentication;
using XTGlobal.Common.DTO.User;

namespace XTGlobal.API.Controllers.Authentication
{
    [Route("api/AuthCRUD")]
    public class AuthCRUDController : ControllerBase
    {
		private IAuthCRUDManager _authCRUDManager = null;
		private IMapper _mapper = null;
		private JwtSettings _jwtSettings = null;

		public AuthCRUDController(IAuthCRUDManager authCRUDManager, IMapper mapper, JwtSettings jwtSettings)
		{
			_authCRUDManager = authCRUDManager ??
				throw new ArgumentNullException(nameof(authCRUDManager));
			_mapper = mapper ??
				throw new ArgumentNullException(nameof(mapper));
			_jwtSettings = jwtSettings ??
				throw new ArgumentNullException(nameof(jwtSettings));
		}

		[HttpPost]
		[Route("LogIn")]
		[AllowAnonymous]
		public AuthResultDto LogIn([FromBody] UserForLoginDto loginDto)
		{
			try
			{
				var userDto = _authCRUDManager.Login(_mapper.Map<UserDto>(loginDto));
				AuthResultDto authResultDto = new AuthResultDto();
				if (userDto == null)
				{
					return authResultDto;
				}

				var tokenHandler = new JwtSecurityTokenHandler();
				var key = Encoding.ASCII.GetBytes(_jwtSettings.JwtSecret);
				var tokenDescriptor = new SecurityTokenDescriptor()
				{
					Subject = new ClaimsIdentity(new[]
					{
						new Claim(JwtRegisteredClaimNames.Sub, loginDto.Email),
						new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
						new Claim(JwtRegisteredClaimNames.Email, loginDto.Email)
					}),
					Expires = DateTime.UtcNow.AddMinutes(1),
					SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
				};

				var token = tokenHandler.CreateToken(tokenDescriptor);

				authResultDto.Succeeded = true;
				authResultDto.Token = tokenHandler.WriteToken(token);

				return authResultDto;
			}
			catch (Exception ex)
			{
				throw ex;
			}

		}
    }
}