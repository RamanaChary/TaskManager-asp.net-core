﻿using System;
using System.Net;
using AutoMapper;
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.ApiModels.Task.Create;
using XTGlobal.API.ApiModels.Task.Update;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Tasks;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;
using XTGlobal.API.Helpers;

namespace XTGlobal.API.Controllers.Tasks
{
	/// <summary>
	/// Controller to perform CRUD/WRITE operations against Task.
	/// </summary>
	[Route("api/TaskCRUD/Tasks")]
	public class TaskCRUDController : BaseController<TaskDto>
	{
		private ITaskCRUDManager _taskCRUDManager;
		private IMapper _mapper;
		private IValidator<TaskForUpdateDto> _taskForUpdateDtovalidator;

		public TaskCRUDController(ITaskCRUDManager taskCRUDManager, IMapper mapper, IValidator<TaskForUpdateDto> taskForUpdateDtovalidator) : base(mapper)
		{
			_taskCRUDManager = taskCRUDManager;
			_mapper = mapper;
			_taskForUpdateDtovalidator = taskForUpdateDtovalidator;
		}

		[HttpPost]
		[Route("",Name = "CreateTask")]
		[ProducesResponseType(StatusCodes.Status201Created, Type = typeof(IApiCreatedResponse))]
		[ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(IApiResponseWithValidation))]
		public IActionResult Post([FromBody] TaskForCreationDto userTask
			, [FromServices] IValidator<TaskForCreationDto> taskForCreationDtovalidator)
		{
			try
			{
				var validationResult = taskForCreationDtovalidator.Validate(userTask);

				if (!validationResult.IsValid)
				{
					return Create400BadRequestResponse(validationResult);
				}

				var taskForCreation = _mapper.Map<TaskDto>(userTask);

				var taskId = _taskCRUDManager.Add(taskForCreation);

				return Create201CreatedResponse("GetTaskByTaskId", taskId);
			}
			catch (Exception ex)
			{
				return Create500InternalServerErrorResponse(ex.Message);
			}
		}
		
		[HttpPut]
		[Route("{Id}", Name = "UpdateTask")]
		[ProducesResponseType(StatusCodes.Status204NoContent, Type = typeof(IApiResponseWithValidation))]
		[ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(IApiResponseWithValidation))]
		[ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(IApiResponseWithValidation))]
		public IActionResult Put([FromBody] TaskForUpdateDto userTask, Guid Id)
        {
			try
			{
				var validationResult = _taskForUpdateDtovalidator.Validate(userTask);

				if (!validationResult.IsValid)
				{
					return Create400BadRequestResponse(validationResult);
				}

				var existingTask = _taskCRUDManager.TaskExists(Id);

				if(existingTask == null)
				{
					return Create404NotFoundResponse();
				}

				var taskForUpdate = _mapper.Map(userTask, existingTask);
				_taskCRUDManager.Update(taskForUpdate);

				return Create204NoContentResponse();
			}
			catch (Exception ex)
			{
				return Create500InternalServerErrorResponse(ex.Message);
			}
        }

		[HttpPatch]
		[Route("{Id}", Name = "UpdatePartialTask")]
		[ProducesResponseType(StatusCodes.Status204NoContent, Type = typeof(IApiResponseWithValidation))]
		[ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(IApiResponseWithValidation))]
		[ProducesResponseType(StatusCodes.Status400BadRequest, Type = typeof(IApiResponseWithValidation))]
		public IActionResult Patch([FromBody] JsonPatchDocument<TaskForUpdateDto> patchDocument, Guid Id)
		{
			try
			{
				//Step 1. Get the task by taskId
				var existingTask = _taskCRUDManager.TaskExists(Id);

				if(existingTask == null)
				{
					return Create404NotFoundResponse();
				}

				//Step 2. Map the existing task to TaskForUpdateDto
				var taskToPatch = _mapper.Map<TaskForUpdateDto>(existingTask);

				//Step 3. Apply changes from JsonPatchDocument to the above dto
				patchDocument.ApplyTo(taskToPatch);

				//Step 4. validate the taskToPatch
				var validationResult = _taskForUpdateDtovalidator.Validate(taskToPatch);

				if (!validationResult.IsValid)
				{
					return Create400BadRequestResponse(validationResult);
				}

				//Step 5. Map the patched TaskForUpdateDto to TaskDto inorder for update to db
				var taskForUpdate = _mapper.Map(taskToPatch, existingTask);

				//Step 6. Commit changes to db
				_taskCRUDManager.Update(taskForUpdate);

				return Create204NoContentResponse();
			}
			catch (Exception ex)
			{
				return Create500InternalServerErrorResponse(ex.Message);
			}
		}
        
        [HttpDelete]
		[Route("{Id}", Name = "DeleteTask")]
		[ProducesResponseType(StatusCodes.Status204NoContent, Type = typeof(IApiResponse))]
		[ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(IApiResponse))]
		public IActionResult Delete(Guid Id)
        {
			try
			{
				var existingTask = _taskCRUDManager.TaskExists(Id);

				if (existingTask == null)
				{
					return Create404NotFoundResponse();
				}

				_taskCRUDManager.Delete(Id);

				return Create204NoContentResponse();
			}
			catch (Exception ex)
			{
				return Create500InternalServerErrorResponse(ex.Message);
			}
		}
	}
}
