﻿using System;
using System.Net;
using AutoMapper;
using FluentValidation;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.ApiModels.Task.Create;
using XTGlobal.API.ApiModels.Task.Update;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Tasks;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;

namespace XTGlobal.API.Controllers.Tasks
{
	/// <summary>
	/// Controller to perform CRUD/WRITE operations against Task.
	/// </summary>
	[Route("api/TaskCRUD/Tasks")]
	public class TaskCRUDController : BaseController
	{
		private ITaskCRUDManager _taskCRUDManager;
		private IMapper _mapper;
		private IValidator<TaskForUpdateDto> _taskForUpdateDtovalidator;

		public TaskCRUDController(ITaskCRUDManager taskCRUDManager, IMapper mapper, IValidator<TaskForUpdateDto> taskForUpdateDtovalidator)
		{
			_taskCRUDManager = taskCRUDManager;
			_mapper = mapper;
			_taskForUpdateDtovalidator = taskForUpdateDtovalidator;
		}

		[HttpPost]
		[Route("",Name = "CreateTask")]
		public IApiResponse Post([FromBody] TaskForCreationDto userTask, [FromServices] IValidator<TaskForCreationDto> taskForCreationDtovalidator
			, [FromServices] IApiCreatedResponse apiResponse)
		{
			try
			{
				var validationResult = taskForCreationDtovalidator.Validate(userTask);

				if (!validationResult.IsValid)
				{
					apiResponse.MessageID = HttpStatusCode.BadRequest;
					apiResponse.MessageText = "BadRequest";
					apiResponse.Errors = validationResult.Errors?.AddToValidationStatus();

					return apiResponse;
				}

				var taskForCreation = _mapper.Map<TaskDto>(userTask);

				var taskId = _taskCRUDManager.Add(taskForCreation);

				apiResponse.MessageID = HttpStatusCode.Created;
				apiResponse.MessageText = "Created";
				apiResponse.CreatedAtUri = CreateNewUri("GetTaskByTaskId", taskId);
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		private CreatedAtUri CreateNewUri(string routeName, Guid taskId)
		{
			return new CreatedAtUri()
			{
				Uri = Url.Link(routeName, new { taskId }),
				Method = "GET"
			};
		}

		[HttpPut]
		[Route("{taskId}", Name = "UpdateTask")]
		public IApiResponse Put([FromBody] TaskForUpdateDto userTask, Guid taskId, [FromServices] IApiResponse apiResponse)
        {
			try
			{
				var validationResult = _taskForUpdateDtovalidator.Validate(userTask);

				if (!validationResult.IsValid)
				{
					apiResponse.MessageID = HttpStatusCode.BadRequest;
					apiResponse.MessageText = "BadRequest";
					apiResponse.Errors = validationResult.Errors?.AddToValidationStatus();

					return apiResponse;
				}

				var existingTask = _taskCRUDManager.TaskExists(taskId);

				if(existingTask == null)
				{
					apiResponse.MessageID = HttpStatusCode.NotFound;
					apiResponse.MessageText = "NotFound";

					return apiResponse;
				}

				var taskForUpdate = _mapper.Map(userTask, existingTask);
				_taskCRUDManager.Update(taskForUpdate);

				apiResponse.MessageID = HttpStatusCode.NoContent;
				apiResponse.MessageText = "NoContent";
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
        }

		[HttpPatch]
		[Route("{taskId}", Name = "UpdatePartialTask")]
		public IApiResponse Patch([FromBody] JsonPatchDocument<TaskForUpdateDto> patchDocument, Guid taskId, [FromServices] IApiResponse apiResponse)
		{
			try
			{
				//Step 1. Get the task by taskId
				var existingTask = _taskCRUDManager.TaskExists(taskId);

				if(existingTask == null)
				{
					apiResponse.MessageID = HttpStatusCode.NotFound;
					apiResponse.MessageText = "NotFound";

					return apiResponse;
				}

				//Step 2. Map the existing task to TaskForUpdateDto
				var taskToPatch = _mapper.Map<TaskForUpdateDto>(existingTask);

				//Step 3. Apply changes from JsonPatchDocument to the above dto
				patchDocument.ApplyTo(taskToPatch);

				//Step 4. validate the taskToPatch
				var validationResult = _taskForUpdateDtovalidator.Validate(taskToPatch);

				if (!validationResult.IsValid)
				{
					apiResponse.MessageID = HttpStatusCode.BadRequest;
					apiResponse.MessageText = "BadRequest";
					apiResponse.Errors = validationResult.Errors?.AddToValidationStatus();

					return apiResponse;
				}

				//Step 5. Map the patched TaskForUpdateDto to TaskDto inorder for update to db
				var taskForUpdate = _mapper.Map(taskToPatch, existingTask);

				//Step 6. Commit changes to db
				_taskCRUDManager.Update(taskForUpdate);

				apiResponse.MessageID = HttpStatusCode.NoContent;
				apiResponse.MessageText = "NoContent";
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}
        
        [HttpDelete]
		[Route("{taskId}", Name = "DeleteTask")]
		public IApiResponse Delete(Guid taskId, [FromServices] IApiResponse apiResponse)
        {
			try
			{
				var existingTask = _taskCRUDManager.TaskExists(taskId);

				if (existingTask == null)
				{
					apiResponse.MessageID = HttpStatusCode.NotFound;
					apiResponse.MessageText = "NotFound";

					return apiResponse;
				}

				_taskCRUDManager.Delete(taskId);

				apiResponse.MessageID = HttpStatusCode.NoContent;
				apiResponse.MessageText = "NoContent";
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}
    }
}
