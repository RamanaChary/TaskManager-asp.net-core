﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using AutoMapper;
using Marvin.Cache.Headers;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Tasks;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;

namespace XTGlobal.API.Controllers.Tasks
{
	/// <summary>
	/// Controller to perform GET/READ operations against Task.
	/// </summary>
	[Route("api/TaskVIEW/Tasks")]
	[HttpCacheExpiration(CacheLocation = CacheLocation.Public, MaxAge = 600)]
	[HttpCacheValidation(MustRevalidate = true)]
	public class TaskVIEWController : BaseController
	{
		private ITaskVIEWManager _taskVIEWManager;
		private AppSettings _appSettings;
		private IMapper _mapper;

		public TaskVIEWController(ITaskVIEWManager taskVIEWManager, AppSettings appSettings, IMapper mapper)
		{
			_taskVIEWManager = taskVIEWManager;
			_appSettings = appSettings;
			_mapper = mapper;
		}

		[HttpGet]
		[Route("",Name = "GetAllTasks")]
        public IApiCollectionResponse<TaskDto> GetAllTasks([FromQuery] TaskResourceParameters parameters
			, [FromServices] IApiCollectionResponse<TaskDto> apiResponse)
        {
			try
			{
				var userTasks = _taskVIEWManager.GetAllTasks(parameters);

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Result = CreateResourceCollectionResult(userTasks, null);
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
        }

		[HttpGet]
		[Route("{taskId}", Name = "GetTaskByTaskId")]
		public IApiResponse<TaskDto> GetTaskByTaskId([FromRoute] Guid taskId, [FromServices] IApiResponse<TaskDto> apiResponse)
		{
			try
			{
				var userTask = _taskVIEWManager.GetTask(taskId);

				if (userTask == null)
				{
					apiResponse.MessageID = HttpStatusCode.NotFound;
					apiResponse.MessageText = "NotFound";

					return apiResponse;
				}

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Result = CreateResourceResult(userTask);
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		[HttpGet]
		[Route("OverDue", Name = "GetOverDueTasks")]
		public IApiCollectionResponse<TaskDto> GetOverDueTasks([FromQuery] string dueDate, [FromQuery] TaskResourceParameters parameters
			, [FromServices] IApiCollectionResponse<TaskDto> apiResponse)
		{
			DateTime overDueDate = string.IsNullOrWhiteSpace(dueDate) ? DateTime.UtcNow : Convert.ToDateTime(dueDate);
			try
			{
				var userTasks = _taskVIEWManager.GetOverDueTasks(overDueDate, parameters);

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Result = CreateResourceCollectionResult(userTasks, null);
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		[HttpGet]
		[Route("Completed", Name = "GetCompletedTasks")]
		public IApiCollectionResponse<TaskDto> GetCompletedTasks([FromQuery] TaskResourceParameters parameters
			, [FromServices] IApiCollectionResponse<TaskDto> apiResponse)
		{
			try
			{
				var userTasks = _taskVIEWManager.GetCompletedTasks(parameters);

				apiResponse.MessageID = HttpStatusCode.OK;
				apiResponse.MessageText = "Success";
				apiResponse.Result = CreateResourceCollectionResult(userTasks, null);
			}
			catch (Exception ex)
			{
				apiResponse.MessageID = HttpStatusCode.InternalServerError;
				apiResponse.MessageText = ex.Message;
			}

			return apiResponse;
		}

		private CollectionResource<TaskDto> CreateResourceCollectionResult(PagedList<TaskDto> userTasks,string fields)
		{
			var colletionResource = new CollectionResource<TaskDto>();
			var actionName = ControllerContext.RouteData.Values["action"];

			if (userTasks != null && userTasks.Count() > 0)
			{
				userTasks.ForEach(x =>
				{
					colletionResource.Records.Add(new Resource<TaskDto>(x));
				});
			}

			if (_appSettings.CreateHypermediaLinks)
			{
				if (colletionResource != null && colletionResource.Records.Count() > 0)
				{
					colletionResource.Records.ForEach(x =>
					{
						x.Links = GenerateResourceLinks(x.Record.TaskID);
					});

					colletionResource.PageLinks = GeneratePageLinks(colletionResource.Records, actionName.ToString(), fields);
				}

			}

			return colletionResource;
		}

		private Resource<TaskDto> CreateResourceResult(TaskDto userTask)
		{
			var resource = new Resource<TaskDto>(userTask);

			if (_appSettings.CreateHypermediaLinks)
			{
				if (resource != null)
				{
					resource.Links = GenerateResourceLinks(resource.Record.TaskID);
				}

			}

			return resource;
		}

		private List<Link> GenerateResourceLinks(Guid taskId)
		{
			var links = new List<Link>();

			links.Add(new Link(Url.Link(nameof(GetTaskByTaskId), new { taskId }), "Self", "GET"));
			links.Add(new Link(Url.Link("CreateTask", null), "create_task", "POST"));
			links.Add(new Link(Url.Link("UpdateTask", new { taskId }), "update_task", "PUT"));
			links.Add(new Link(Url.Link("UpdatePartialTask", new { taskId }), "update_partial_task", "PATCH"));
			links.Add(new Link(Url.Link("DeleteTask", new { taskId }), "delete_task", "DELETE"));

			return links;
		}

		private List<PageLink> GeneratePageLinks(PagedList<Resource<TaskDto>> resources, string actionName, string fields)
		{
			var pageLinks = new List<PageLink>();

			pageLinks.Add(new PageLink(Url.Link(actionName, new { fields }), "Self", "GET"));

			if(resources.HasPrevious)
				pageLinks.Add(new PageLink(Url.Link(actionName, new { fields }), "Previous", "GET"));

			if(resources.HasNext)
				pageLinks.Add(new PageLink(Url.Link(actionName, new { fields }), "Next", "GET"));

			return pageLinks;
		}
	}
}
