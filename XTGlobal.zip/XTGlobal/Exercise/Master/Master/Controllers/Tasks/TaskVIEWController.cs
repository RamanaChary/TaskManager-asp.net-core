﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using AutoMapper;
using Marvin.Cache.Headers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Tasks;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;
using XTGlobal.API.Helpers;

namespace XTGlobal.API.Controllers.Tasks
{
	/// <summary>
	/// Controller to perform GET/READ operations against Task.
	/// </summary>
	[Route("api/TaskVIEW/Tasks")]
	//[HttpCacheExpiration(CacheLocation = CacheLocation.Public, MaxAge = 600)]
	//[HttpCacheValidation(MustRevalidate = true)]	
	public class TaskVIEWController : BaseController
	{
		private ITaskVIEWManager _taskVIEWManager;
		private AppSettings _appSettings;
		private IMapper _mapper;

		public TaskVIEWController(ITaskVIEWManager taskVIEWManager, AppSettings appSettings, IMapper mapper) : base(mapper)
		{
			_taskVIEWManager = taskVIEWManager;
			_appSettings = appSettings;
			_mapper = mapper;
		}

		/// <summary>
		/// Get all tasks by criteria
		/// </summary>
		/// <param name="parameters"></param>
		/// <param name="apiResponse"></param>
		/// <returns>A collection of tasks</returns>
		/// <response code="401">Unauthorized request</response>
		/// <response code="200">Request is processed successfully</response>
		/// <response code="401">Request could not be processed due to internal server error</response>
		[HttpGet]
		[Route("", Name = "GetAllTasks")]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponse<TaskDto>))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponseWithLinks<TaskDto>))]
		public IActionResult GetAllTasks([FromQuery] bool requireLinks
			, [FromQuery] TaskResourceParameters parameters
			, [FromServices] IApiCollectionResourceResponse<TaskDto>  apiCollectionResourceResponse
			, [FromServices] IApiCollectionResourceResponseWithLinks<TaskDto> apiCollectionResourceResponseWithLinks
			, [FromServices] IApiErrorResponse apiErrorResponse)
        {
			try
			{
				var userTasks = _taskVIEWManager.GetAllTasks(parameters);

				if(requireLinks)
				{
					apiCollectionResourceResponseWithLinks.Result = CreateCollectionResourceResultWithLinks(userTasks, parameters);
					return apiCollectionResourceResponseWithLinks.Create200SuccessResponse<TaskDto>();
				}

				apiCollectionResourceResponse.Result = CreateCollectionResourceResult(userTasks);
				return apiCollectionResourceResponse.Create200SuccessResponse<TaskDto>();
			}
			catch (Exception ex)
			{
				return apiErrorResponse.Create500InternalServerErrorResponse(ex.Message);
			}
        }

		[HttpGet]
		[Route("{Id}", Name = "GetTaskByTaskId")]
		[ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(IApiResponse))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiSingleResourceResponse<TaskDto>))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiSingleResourceResponseWithLinks<TaskDto>))]
		public IActionResult GetTaskByTaskId([FromRoute] Guid Id
			,[FromQuery] bool requireLinks
			, [FromServices] IApiSingleResourceResponse<TaskDto> apiSingleResourceResponse
			, [FromServices] IApiSingleResourceResponseWithLinks<TaskDto> apiSingleResourceResponseWithLinks
			, [FromServices] IApiResponse apiResponse
			, [FromServices] IApiErrorResponse apiErrorResponse)
		{
			try
			{
				var userTask = _taskVIEWManager.GetTask(Id);

				if (userTask == null)
				{
					return apiResponse.Create404NotFoundResponse();
				}

				if (requireLinks)
				{
					apiSingleResourceResponseWithLinks.Result = CreateSingleResourceResultWithLinks(userTask);
					return apiSingleResourceResponseWithLinks.Create200SuccessResponse<TaskDto>();
				}

				apiSingleResourceResponse.Result = CreateSingleResourceResult(userTask);
				return apiSingleResourceResponse.Create200SuccessResponse<TaskDto>();
			}
			catch (Exception ex)
			{
				return apiErrorResponse.Create500InternalServerErrorResponse(ex.Message);
			}
		}

		[HttpGet]
		[Route("OverDue", Name = "GetOverDueTasks")]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponse<TaskDto>))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponseWithLinks<TaskDto>))]
		public IActionResult GetOverDueTasks([FromQuery] bool requireLinks
			, [FromQuery] string dueDate
			, [FromQuery] TaskResourceParameters parameters
			, [FromServices] IApiCollectionResourceResponse<TaskDto> apiCollectionResourceResponse
			, [FromServices] IApiCollectionResourceResponseWithLinks<TaskDto> apiCollectionResourceResponseWithLinks
			, [FromServices] IApiErrorResponse apiErrorResponse)
		{
			DateTime overDueDate = string.IsNullOrWhiteSpace(dueDate) ? DateTime.UtcNow : Convert.ToDateTime(dueDate);
			try
			{
				var userTasks = _taskVIEWManager.GetOverDueTasks(overDueDate, parameters);

				if(requireLinks)
				{
					apiCollectionResourceResponseWithLinks.Result = CreateCollectionResourceResultWithLinks(userTasks, parameters);
					return apiCollectionResourceResponseWithLinks.Create200SuccessResponse<TaskDto>();
				}

				apiCollectionResourceResponse.Result = CreateCollectionResourceResult(userTasks);
				return apiCollectionResourceResponse.Create200SuccessResponse<TaskDto>();
			}
			catch (Exception ex)
			{
				return apiErrorResponse.Create500InternalServerErrorResponse(ex.Message);
			}
		}

		[HttpGet]
		[Route("Completed", Name = "GetCompletedTasks")]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponse<TaskDto>))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponseWithLinks<TaskDto>))]
		public IActionResult GetCompletedTasks([FromQuery] bool requireLinks
			, [FromQuery] TaskResourceParameters parameters
			, [FromServices] IApiCollectionResourceResponse<TaskDto> apiCollectionResourceResponse
			, [FromServices] IApiCollectionResourceResponseWithLinks<TaskDto> apiCollectionResourceResponseWithLinks
			, [FromServices] IApiErrorResponse apiErrorResponse)
		{
			try
			{
				var userTasks = _taskVIEWManager.GetCompletedTasks(parameters);

				if(requireLinks)
				{
					apiCollectionResourceResponseWithLinks.Result = CreateCollectionResourceResultWithLinks(userTasks, parameters);
					return apiCollectionResourceResponseWithLinks.Create200SuccessResponse<TaskDto>();
				}

				apiCollectionResourceResponse.Result = CreateCollectionResourceResult(userTasks);
				return apiCollectionResourceResponse.Create200SuccessResponse<TaskDto>();
			}
			catch (Exception ex)
			{
				return apiErrorResponse.Create500InternalServerErrorResponse(ex.Message);
			}
		}
	}
}
