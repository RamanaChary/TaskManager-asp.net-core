﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using XTGlobal.Common.DTO.Infrastructure;

namespace XTGlobal.API.Infrastructure
{
	public class ApiResponse<T> : IApiResponse<T> where T : class
	{
		public HttpStatusCode MessageID { get; set; }
		public string MessageText { get; set; }
		public List<CollectionResource<T>> Result { get; set; }
		public List<ValidationStatus> Errors { get; set; } = new List<ValidationStatus>();
		public int Count { get; set; }
	}

	public class ApiResponse : IApiResponse
	{
		public HttpStatusCode MessageID { get; set; }
		public string MessageText { get; set; }
		public List<ValidationStatus> Errors { get; set; } = new List<ValidationStatus>();
		public List<Link> Links { get; set; } = new List<Link>();
	}
}
