﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using XTGlobal.Common.DTO.Infrastructure;

namespace XTGlobal.API.Infrastructure
{
	public class BaseApiResponse
	{
		public int MessageID { get; set; }
		public string MessageText { get; set; }
	}

	public class BaseApiReponseWithValidation : BaseApiResponse
	{
		public bool HasValidationErrors => ValidationResult?.Count > 0;
		public List<ValidationStatus> ValidationResult { get; set; } = new List<ValidationStatus>();
	}
	public class ApiCollectionResourceResponse<T> : BaseApiResponse, IApiCollectionResourceResponse<T> where T : class
	{
		public CollectionResource<T> Result { get; set; }
	}
	public class ApiCollectionResourceResponseWithLinks<T> : BaseApiResponse, IApiCollectionResourceResponseWithLinks<T> where T : class
	{
		public CollectionResourceWithLinks<T> Result { get; set; }
	}
	public class ApiCollectionResourceResponseWithValidation<T> : BaseApiReponseWithValidation, IApiCollectionResourceResponseWithValidation<T> where T : class
	{
		public CollectionResource<T> Result { get; set; }
	}

	public class ApiSingleResourceResponse<T> : BaseApiResponse, IApiSingleResourceResponse<T> where T : class
	{
		public Resource<T> Result { get; set; }
	}
	public class ApiSingleResourceResponseWithLinks<T> : BaseApiResponse, IApiSingleResourceResponseWithLinks<T> where T : class
	{
		public ResourceWithLinks<T> Result { get; set; }
	}

	public class ApiSingleResourceResponseWithValidation<T> : BaseApiReponseWithValidation, IApiSingleResourceResponseWithValidation<T> where T : class
	{
		public Resource<T> Result { get; set; }
	}

	public class ApiCreatedResponse :BaseApiResponse, IApiCreatedResponse
	{
		public CreatedAtUri CreatedAtUri { get; set; } = new CreatedAtUri();
	}

	public class ApiErrorResponse : IApiErrorResponse
	{
		public int MessageID { get; set; }
		public string MessageText { get; set; }
		public ServerError ServerError { get; set; } = new ServerError();
	}

	public class ApiResponse : BaseApiResponse, IApiResponse
	{

	}

	public class ApiResponseWithValidation :BaseApiReponseWithValidation, IApiResponseWithValidation
	{

	}
}
