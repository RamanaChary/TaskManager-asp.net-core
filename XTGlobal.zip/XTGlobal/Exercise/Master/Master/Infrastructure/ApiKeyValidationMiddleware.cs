﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace XTGlobal.API.Infrastructure
{
	public class ApiKeyValidationMiddleware
	{
		private const string APIKey = "1234";
		private readonly RequestDelegate _next;

		public ApiKeyValidationMiddleware(RequestDelegate next)
		{
			_next = next;
		}

		public async Task Invoke(HttpContext context)
		{
			if (!context.Request.Headers.Keys.Contains("APIKey"))
			{
				context.Response.StatusCode = (int) HttpStatusCode.BadRequest; //Bad Request                
				await context.Response.WriteAsync("APIKey is missing");
				return;
			}
			else
			{
				if (!CheckValidUserKey(context.Request.Headers["APIKey"]))
				{
					context.Response.StatusCode = (int)HttpStatusCode.Unauthorized; //UnAuthorized
					await context.Response.WriteAsync("Invalid APIKey");
					return;
				}
			}

			await _next.Invoke(context);
		}

		private bool CheckValidUserKey(string key)
		{
			bool validKey = false;
			if(key == APIKey)
			{
				validKey = true;
			}
			else
			{
				validKey = false;
			}

			return validKey;
		}
	}

	#region ExtensionMethod
	public static class UserKeyValidatorsExtension
	{
		public static IApplicationBuilder ApplyUserKeyValidation(this IApplicationBuilder app)
		{
			return app.UseMiddleware<ApiKeyValidationMiddleware>();
		}
	}
	#endregion
}
