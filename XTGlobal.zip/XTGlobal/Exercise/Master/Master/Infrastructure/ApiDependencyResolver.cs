﻿using FluentValidation;
using Microsoft.Extensions.DependencyInjection;
using XTGlobal.API.ApiModels.Task.Create;
using XTGlobal.API.ApiModels.Task.Update;

namespace XTGlobal.API.Infrastructure
{
	/// <summary>
	/// Inject api layer dependencies
	/// </summary>
	public static class ApiDependencyResolver
    {
		public static void AddApiDependency(this IServiceCollection services)
		{
			services.AddTransient<IValidator<TaskForCreationDto>, TaskForCreationDtoValidator>();
			services.AddTransient<IValidator<TaskForUpdateDto>, TaskForUpdateDtoValidator>();

			//Api response
			services.AddTransient<IApiResponse, ApiResponse>();
			services.AddTransient<IApiResponseWithValidation, ApiResponseWithValidation>();
			services.AddTransient<IApiCreatedResponse, ApiCreatedResponse>();
			services.AddTransient<IApiErrorResponse, ApiErrorResponse>();
			services.AddTransient(typeof(IApiCollectionResourceResponse<>), typeof(ApiCollectionResourceResponse<>));
			services.AddTransient(typeof(IApiCollectionResourceResponseWithLinks<>), typeof(ApiCollectionResourceResponseWithLinks<>));
			services.AddTransient(typeof(IApiSingleResourceResponse<>), typeof(ApiSingleResourceResponse<>));
			services.AddTransient(typeof(IApiSingleResourceResponseWithLinks<>), typeof(ApiSingleResourceResponseWithLinks<>));
		}
	}
}
