﻿using FluentValidation;
using Microsoft.Extensions.DependencyInjection;
using XTGlobal.API.ApiModels.Task.Create;
using XTGlobal.API.ApiModels.Task.Update;

namespace XTGlobal.API.Infrastructure
{
	/// <summary>
	/// Inject api layer dependencies
	/// </summary>
	public static class ApiDependencyResolver
    {
		public static void AddApiDependency(this IServiceCollection services)
		{
			services.AddTransient<IValidator<TaskForCreationDto>, TaskForCreationDtoValidator>();
			services.AddTransient<IValidator<TaskForUpdateDto>, TaskForUpdateDtoValidator>();
			services.AddScoped<IApiResponse, ApiResponse>();
			services.AddScoped<IApiCreatedResponse, ApiCreatedResponse>();
			services.AddScoped(typeof(IApiCollectionResponse<>), typeof(ApiCollectionResponse<>));
			services.AddScoped(typeof(IApiResponse<>), typeof(ApiResponse<>));
		}
	}
}
