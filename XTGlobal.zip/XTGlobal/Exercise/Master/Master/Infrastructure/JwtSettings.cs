﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XTGlobal.API.Infrastructure
{
    public class JwtSettings
    {
		public string JwtSecret { get; set; }
	}
}
