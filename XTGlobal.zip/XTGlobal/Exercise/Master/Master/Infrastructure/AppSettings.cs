﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XTGlobal.API.Infrastructure
{
    public class AppSettings
    {
		public string JwtSecret { get; set; }
		public string Issuer { get; set; }
		public string Audience { get; set; }
		public int ExpiresIn { get; set; }
		public bool UseJwtAuthentication { get; set; }
		public bool UseCaching { get; set; }
	}
}
