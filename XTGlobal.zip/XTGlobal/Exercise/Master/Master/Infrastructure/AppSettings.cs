﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XTGlobal.API.Infrastructure
{
    public class AppSettings
    {
		public string JwtSecret { get; set; }
		public bool UseJwtAuthentication { get; set; }
		public bool UseCaching { get; set; }
		public bool CreateHypermediaLinks { get; set; }
	}
}
