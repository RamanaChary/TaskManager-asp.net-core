﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using XTGlobal.Common.DTO.Infrastructure;

namespace XTGlobal.API.Infrastructure
{
    public interface IApiResponse<T> where T : class
    {
		HttpStatusCode MessageID { get; set; }
		string MessageText { get; set; }
		List<CollectionResource<T>> Result { get; set; }
		List<ValidationStatus> Errors { get; set; }
		int Count { get; set; }
	}

	public interface IApiResponse
	{
		HttpStatusCode MessageID { get; set; }
		string MessageText { get; set; }
		List<ValidationStatus> Errors { get; set; }
		List<Link> Links { get; set; }
	}
}
