﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using XTGlobal.Common.DTO.Infrastructure;

namespace XTGlobal.API.Infrastructure
{
    public interface IApiCollectionResponse<T> where T : class
    {
		HttpStatusCode MessageID { get; set; }
		string MessageText { get; set; }
		CollectionResource<T> Result { get; set; }
		List<ValidationStatus> Errors { get; set; }
	}

	public interface IApiResponse<T> where T : class
	{
		HttpStatusCode MessageID { get; set; }
		string MessageText { get; set; }
		Resource<T> Result { get; set; }
		List<ValidationStatus> Errors { get; set; }
	}

	public interface IApiResponse
	{
		HttpStatusCode MessageID { get; set; }
		string MessageText { get; set; }
		List<ValidationStatus> Errors { get; set; }
	}

	public interface IApiCreatedResponse : IApiResponse
	{
		CreatedAtUri CreatedAtUri { get; set; }
	}
}
