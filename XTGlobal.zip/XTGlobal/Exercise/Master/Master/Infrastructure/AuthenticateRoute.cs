﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Security.Claims;
using XTGlobal.API.Helpers;

namespace XTGlobal.API.Infrastructure
{
	public class AuthenticateRoute : AuthorizeAttribute, IAuthorizationFilter
	{
		private IApiResponse _unauthorizedRouteResult;
		private IApiErrorResponse _apiErrorResponse;
		public void OnAuthorization(AuthorizationFilterContext context)
		{
			try
			{
				_unauthorizedRouteResult = (IApiResponse) context.HttpContext.RequestServices.GetService(typeof(IApiResponse));
				_apiErrorResponse = (IApiErrorResponse)context.HttpContext.RequestServices.GetService(typeof(IApiErrorResponse));

				var user = context.HttpContext.User;

				if (!user.Identity.IsAuthenticated)
				{
					context.Result = _unauthorizedRouteResult.Create401UnauthorizedResponse($"Authentication failed for user {user.Identity?.Name}");
				}
			}
			catch (Exception ex)
			{
				context.Result = _apiErrorResponse.Create500InternalServerErrorResponse(ex.Message);
			}
        }

		
	}
}
