﻿namespace XTGlobal.API.Infrastructure
{
	public interface IAppSettings
	{
		string Audience { get; set; }
		bool CreateHypermediaLinks { get; set; }
		int ExpiresIn { get; set; }
		string Issuer { get; set; }
		string JwtSecret { get; set; }
		bool UseCaching { get; set; }
		bool UseJwtAuthentication { get; set; }
	}
}