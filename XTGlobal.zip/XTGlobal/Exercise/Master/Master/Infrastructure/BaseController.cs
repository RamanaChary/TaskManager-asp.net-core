﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.Infrastructure;

namespace XTGlobal.API.Infrastructure
{
	/// <summary>
	/// Base controller for all Api controllers
	/// </summary>
//	[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
	public class BaseController : ControllerBase
    {
		public BaseController()
		{

		}

    }
}