﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.Infrastructure;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.API.Helpers;

namespace XTGlobal.API.Infrastructure
{
	/// <summary>
	/// Base controller for all Api controllers
	/// </summary>
	//[ServiceFilter(typeof(AuthorizeRoute))]
	//[AuthenticateRoute(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]	
	[ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(IApiResponse))]
	[ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(IApiErrorResponse))]
	public class BaseController : ControllerBase
    {
		private IMapper _mapper;
		public BaseController(IMapper mapper)
		{
			_mapper = mapper;
		}
		
		private string ControllerName => ControllerContext.RouteData.Values["controller"].ToString();
		private string Controller => ControllerContext.ActionDescriptor.ControllerName;
		private string Action => ControllerContext.ActionDescriptor.ActionName;
		private string ActionName => ControllerContext.RouteData.Values["action"].ToString();
		private string Method => ControllerContext.HttpContext.Request.Method;
		private IUrlHelper UrlHelper => Url;

		protected CollectionResource<T> CreateCollectionResourceResult<T>(PagedList<T> userTasks) where T : class	
		=> _mapper.Map<CollectionResource<T>>(userTasks);

		protected Resource<T> CreateSingleResourceResult<T>(T userTask) where T : class
		=> _mapper.Map<Resource<T>>(userTask);

		protected CollectionResourceWithLinks<T> CreateCollectionResourceResultWithLinks<T>(PagedList<T> userTasks
			, BaseResourceParameters parameters) where T : class
		{
			var colletionResource = _mapper.Map<CollectionResourceWithLinks<T>>(userTasks);

			colletionResource?.GenerateCollectionResourceLinks(UrlHelper, userTasks, ActionName, parameters);

			return colletionResource;
		}

		protected ResourceWithLinks<T> CreateSingleResourceResultWithLinks<T>(T userTask) where T : class
		{
			var resource = _mapper.Map<ResourceWithLinks<T>>(userTask);

			resource?.GenerateSingleResourceLinks(UrlHelper);

			return resource;
		}
	}
}