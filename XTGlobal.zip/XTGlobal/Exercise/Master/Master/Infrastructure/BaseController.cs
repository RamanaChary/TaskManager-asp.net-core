﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.Infrastructure;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.API.Helpers;
using FluentValidation.Results;

namespace XTGlobal.API.Infrastructure
{
	/// <summary>
	/// Base controller for all Api controllers
	/// </summary>
	//[ServiceFilter(typeof(AuthorizeRoute))]
	//[AuthenticateRoute(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]	
	[ProducesResponseType(StatusCodes.Status401Unauthorized, Type = typeof(IApiResponse))]
	[ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(IApiErrorResponse))]
	public class BaseController<T> : ControllerBase where T : class
    {
		protected IMapper _mapper;
		protected AppSettings _appSettings;
		public BaseController(IMapper mapper, AppSettings appSettings)
		{
			_mapper = mapper;
			_appSettings = appSettings;
		}
		
		protected string ControllerName => ControllerContext.RouteData.Values["controller"].ToString();
		protected string Controller => ControllerContext.ActionDescriptor.ControllerName;
		protected string Action => ControllerContext.ActionDescriptor.ActionName;
		protected string ActionName => ControllerContext.RouteData.Values["action"].ToString();
		protected string Method => ControllerContext.HttpContext.Request.Method;
		protected IUrlHelper UrlHelper => Url;

		protected IActionResult CreateCollectionResource200SuccessReponse(PagedList<T> userTasks)
		{
			IApiCollectionResourceResponse<T> apiCollectionResourceResponse = GetServiceType<IApiCollectionResourceResponse<T>>(typeof(IApiCollectionResourceResponse<T>));
			apiCollectionResourceResponse.Result = _mapper.Map<CollectionResource<T>>(userTasks);
			return apiCollectionResourceResponse.Create200SuccessResponse<T>();
		}

		protected IActionResult CreateSingleResource200SuccessReponse(T userTask)
		{
			IApiSingleResourceResponse<T> apiSingleResourceResponse = GetServiceType<IApiSingleResourceResponse<T>>(typeof(IApiSingleResourceResponse<T>));
			apiSingleResourceResponse.Result = _mapper.Map<Resource<T>>(userTask);
			return apiSingleResourceResponse.Create200SuccessResponse<T>();
		}

		protected IActionResult CreateCollectionResource200SuccessReponseWithLinks(PagedList<T> userTasks
			, BaseResourceParameters parameters
			, bool requireLinks = false)
		{
			IApiCollectionResourceResponseWithLinks<T> apiCollectionResourceResponseWithLinks = GetServiceType<IApiCollectionResourceResponseWithLinks<T>>(typeof(IApiCollectionResourceResponseWithLinks<T>));
			apiCollectionResourceResponseWithLinks.Result = _mapper.Map<CollectionResourceWithLinks<T>>(userTasks);
			apiCollectionResourceResponseWithLinks.Result?.GenerateCollectionResourceLinks(UrlHelper, userTasks, ActionName, parameters, requireLinks);
			return apiCollectionResourceResponseWithLinks.Create200SuccessResponse<T>();
		}

		protected IActionResult CreateSingleResource200SuccessReponseWithLinks(T userTask, bool requireLinks = false)
		{
			IApiSingleResourceResponseWithLinks<T> apiSingleResourceResponseWithLinks = GetServiceType<IApiSingleResourceResponseWithLinks<T>>(typeof(IApiSingleResourceResponseWithLinks<T>));
			apiSingleResourceResponseWithLinks.Result = _mapper.Map<ResourceWithLinks<T>>(userTask);
			apiSingleResourceResponseWithLinks.Result?.GenerateSingleResourceLinks(UrlHelper, requireLinks);
			return apiSingleResourceResponseWithLinks.Create200SuccessResponse<T>();
		}
		protected IActionResult CreateSimple200SuccessResponse()
		{
			IApiResponse apiErrorResponse = GetServiceType<IApiResponse>(typeof(IApiResponse));
			return apiErrorResponse.Create200SuccessResponse();
		}
		protected IActionResult Create500InternalServerErrorResponse(string ex)
		{
			IApiErrorResponse apiErrorResponse = GetServiceType<IApiErrorResponse>(typeof(IApiErrorResponse));
			return apiErrorResponse.Create500InternalServerErrorResponse(ex);
		}

		protected IActionResult Create404NotFoundResponse()
		{
			IApiResponse apiErrorResponse = GetServiceType<IApiResponse>(typeof(IApiResponse));
			return apiErrorResponse.Create404NotFoundResponse();
		}

		protected IActionResult Create204NoContentResponse()
		{
			IApiResponse apiErrorResponse = GetServiceType<IApiResponse>(typeof(IApiResponse));
			return apiErrorResponse.Create204NoContentResponse();
		}

		protected IActionResult Create400BadRequestResponse(ValidationResult validationResult)
		{
			IApiResponseWithValidation apiResponseWithValidation = GetServiceType<IApiResponseWithValidation>(typeof(IApiResponseWithValidation));
			return apiResponseWithValidation.Create400BadRequestResponse(validationResult);
		}

		protected IActionResult Create201CreatedResponse(string getActionName, Guid Id)
		{
			IApiCreatedResponse apiCreatedResponse = GetServiceType<IApiCreatedResponse>(typeof(IApiCreatedResponse));
			return apiCreatedResponse.Create201CreatedResponse(CreateNewUri(getActionName,Id));
		}
		
		protected TResponseType GetServiceType<TResponseType>(Type type) where TResponseType: class
		{
			return (TResponseType) ControllerContext.HttpContext.RequestServices.GetService(type);
		}

		private string CreateNewUri(string routeName, Guid Id)
		{
			return UrlHelper.Link(routeName, new { Id });
		}
	}
}