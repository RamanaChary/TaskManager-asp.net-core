﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XTGlobal.API.Infrastructure
{
	public class ServerError
	{
		public Guid ErrorId { get; set; }
		public string ErrorText { get; set; }
	}
}
