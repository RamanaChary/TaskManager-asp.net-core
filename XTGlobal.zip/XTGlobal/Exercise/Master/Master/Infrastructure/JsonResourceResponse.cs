﻿using Microsoft.AspNetCore.Mvc;

namespace XTGlobal.API.Infrastructure
{
	public class JsonResourceResponse : JsonResult
	{
		public JsonResourceResponse(int? statusCode, object responseObject) : base(responseObject)
		{
			StatusCode = statusCode;
		}
	}
}
