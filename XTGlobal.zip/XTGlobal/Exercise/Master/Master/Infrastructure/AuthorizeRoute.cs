﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Threading;
using XTGlobal.BusinessLogic.Athentication;

namespace XTGlobal.API.Infrastructure
{
	public class AuthorizeRoute : IActionFilter
	{
		IAuthCRUDManager authCRUDManager;
		public AuthorizeRoute(IAuthCRUDManager authCRUDManager)
		{
			this.authCRUDManager = authCRUDManager;
		}
		public void OnActionExecuting(ActionExecutingContext context)
		{
			var email = context.HttpContext.User.Identity?.Name;

			var routeTemplate = context.ActionDescriptor.AttributeRouteInfo.Template;
			var method = context.HttpContext.Request.Method;

			//Check if the user has access to this route
			if(!authCRUDManager.ValidateRoute(email, routeTemplate, method))
				context.Result = new UnauthorizedResult();
		}

		public void OnActionExecuted(ActionExecutedContext context){ }
	}
}
