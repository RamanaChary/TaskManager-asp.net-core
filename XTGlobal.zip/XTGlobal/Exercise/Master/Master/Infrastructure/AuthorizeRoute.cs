﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Threading;
using XTGlobal.BusinessLogic.Athentication;
using XTGlobal.API.Helpers;

namespace XTGlobal.API.Infrastructure
{
	public class AuthorizeRoute : IActionFilter
	{
		private IAuthCRUDManager _authCRUDManager;
		private IApiResponse _unauthorizedRouteResult;
		private IApiErrorResponse _apiErrorResponse;
		public AuthorizeRoute(IAuthCRUDManager authCRUDManager, IApiResponse unauthorizedRouteResult, IApiErrorResponse apiErrorResponse)
		{
			_authCRUDManager = authCRUDManager;
			_unauthorizedRouteResult = unauthorizedRouteResult;
			_apiErrorResponse = apiErrorResponse;
		}
		public void OnActionExecuting(ActionExecutingContext context)
		{
			try
			{
				var email = context.HttpContext.User.Identity?.Name;

				var routeTemplate = context.ActionDescriptor.AttributeRouteInfo.Template;
				var method = context.HttpContext.Request.Method;

				//Check if the user has access to this route
				if (!_authCRUDManager.ValidateRoute(email, routeTemplate, method))
				{
					context.Result = _unauthorizedRouteResult.Create401UnauthorizedResponse($"User {email} does not have access to this route {routeTemplate}");
				}
			}
			catch (Exception ex)
			{
				context.Result = _apiErrorResponse.Create500InternalServerErrorResponse(ex.Message);
			}
						
		}

		public void OnActionExecuted(ActionExecutedContext context){ }
	}
}
