﻿using FluentValidation.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XTGlobal.Common.DTO.Infrastructure;

namespace XTGlobal.API.Infrastructure
{
    public static class ValidationStatusExtenstions
    {
		public static List<ValidationStatus> AddToValidationStatus(this IList<ValidationFailure> validationFailures)
		{
			List<ValidationStatus> Errors = new List<ValidationStatus>();
			foreach (ValidationFailure error in validationFailures)
			{
				Errors.Add(new ValidationStatus()
				{
					 PropertyName = error.PropertyName
					, ErrorMessage = error.ErrorMessage
				});
			}

			return Errors;
		}
    }
}
