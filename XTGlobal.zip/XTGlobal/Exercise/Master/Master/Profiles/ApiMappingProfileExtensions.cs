﻿using AutoMapper;

namespace XTGlobal.API.Profiles
{
	public static class ApiMappingProfileExtensions
	{
		public static void AddApiLayerMappingProfiles(this IMapperConfigurationExpression mc)
		{
			mc.AddProfile(new TaskApiProfile());
			mc.AddProfile(new UserApiProfile());
		}
	}
}
