﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XTGlobal.API.ApiModels.Task.Create;
using XTGlobal.API.ApiModels.Task.Update;
using XTGlobal.Common.DTO.Task;

namespace XTGlobal.API.Profiles
{
    public class TaskProfile : Profile
    {
		public TaskProfile()
		{
			CreateMap<TaskForCreationDto, TaskDto>().ReverseMap();
			CreateMap<TaskForUpdateDto, TaskDto>().ReverseMap();
		}
    }
}
