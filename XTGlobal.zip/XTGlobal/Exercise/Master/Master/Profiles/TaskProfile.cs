﻿using AutoMapper;
using XTGlobal.API.ApiModels.Task.Create;
using XTGlobal.API.ApiModels.Task.Update;
using XTGlobal.Common.DTO.Task;

namespace XTGlobal.API.Profiles
{
	public class TaskProfile : Profile 
    {
		public TaskProfile()
		{
			CreateMap<TaskForCreationDto, TaskDto>().ReverseMap();
			CreateMap<TaskForUpdateDto, TaskDto>().ReverseMap();
		}
    }
}
