﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XTGlobal.API.ApiModels.Athentication.Login;
using XTGlobal.Common.DTO.User;

namespace XTGlobal.API.Profiles
{
    public class UserProfile : Profile
    {
		public UserProfile()
		{
			CreateMap<UserForLoginDto, UserDto>();
		}
    }
}
