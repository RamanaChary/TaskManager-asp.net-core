﻿using AutoMapper;
using System.Collections.Generic;
using XTGlobal.API.ApiModels.Task.Create;
using XTGlobal.API.ApiModels.Task.Update;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;

namespace XTGlobal.API.Profiles
{
	public class TaskApiProfile : Profile 
    {
		public TaskApiProfile()
		{
			CreateMap<TaskForCreationDto, TaskDto>().ReverseMap();
			CreateMap<TaskForUpdateDto, TaskDto>().ReverseMap();
			CreateMap<TaskDto, Resource<TaskDto>>()
				.ForMember(dest => dest.Record, opts => opts.MapFrom(x => x))
				.ForMember(dest => dest.Id, opts => opts.MapFrom(x => x.TaskID));
			CreateMap<TaskDto, ResourceWithLinks<TaskDto>>()
				.ForMember(dest => dest.Record, opts => opts.MapFrom(x => x))
				.ForMember(dest => dest.Id, opts => opts.MapFrom(x => x.TaskID));
			CreateMap<List<Resource<TaskDto>>, CollectionResource<TaskDto>>()
				.ForMember(dest => dest.Records, opts => opts.MapFrom(x => x));
			CreateMap<List<ResourceWithLinks<TaskDto>>, CollectionResourceWithLinks<TaskDto>>()
				.ForMember(dest => dest.Records, opts => opts.MapFrom(x => x));
			CreateMap<PagedList<TaskDto>, CollectionResource<TaskDto>>()
				.ForMember(dest => dest.Records, opts => opts.MapFrom(x => x.Items));
			CreateMap<PagedList<TaskDto>, CollectionResourceWithLinks<TaskDto>>()
				.ForMember(dest => dest.Records, opts => opts.MapFrom(x => x.Items));
		}
    }
}
