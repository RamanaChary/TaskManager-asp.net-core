﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XTGlobal.API.ApiModels.Athentication.Update
{
    public class UserForUpdateDto
    {
    }
}
