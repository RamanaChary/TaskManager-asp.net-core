﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XTGlobal.API.ApiModels.Task.Update
{
    public class TaskForUpdateDto
    {
		public string Title { get; set; }
		public string Description { get; set; }
		public string DueDate { get; set; }
		public int? UserID { get; set; }
		public bool IsCompleted { get; set; }
	}
}
