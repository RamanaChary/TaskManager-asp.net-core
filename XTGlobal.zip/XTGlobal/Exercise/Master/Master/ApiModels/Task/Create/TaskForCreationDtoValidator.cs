﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XTGlobal.API.ApiModels.Task.Create
{
    public class TaskForCreationDtoValidator : AbstractValidator<TaskForCreationDto>
    {
		public TaskForCreationDtoValidator()
		{
			RuleFor(x => x.Title)
				.NotNull().WithMessage("Title can not be null")
				.NotEmpty().WithMessage("Title can not be empty");

			RuleFor(x => x.Description)
				.NotNull().WithMessage("Description can not be null")
				.NotEmpty().WithMessage("Description can not be empty");
		}
    }
}
