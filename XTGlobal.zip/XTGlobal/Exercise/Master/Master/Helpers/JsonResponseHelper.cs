﻿using FluentValidation.Results;
using Microsoft.AspNetCore.Http;
using System;
using XTGlobal.API.Infrastructure;

namespace XTGlobal.API.Helpers
{
	public static class JsonResponseHelper
	{
		public static JsonResourceResponse Create500InternalServerErrorResponse(this IApiErrorResponse apiErrorResponse, string exception)
		{
			apiErrorResponse.MessageID = StatusCodes.Status500InternalServerError;
			apiErrorResponse.MessageText = "InternalServerError";
			apiErrorResponse.ServerError.ErrorId = Guid.NewGuid();
			apiErrorResponse.ServerError.ErrorText = exception;

			return apiErrorResponse.ConvertToJsonApiResponse();
		}

		public static JsonResourceResponse Create400BadRequestResponse(this IApiResponseWithValidation apiResponseWithValidation, ValidationResult validationResult)
		{
			apiResponseWithValidation.MessageID = StatusCodes.Status400BadRequest;
			apiResponseWithValidation.MessageText = "BadRequest";
			apiResponseWithValidation.ValidationResult = validationResult.Errors?.AddToValidationStatus();

			return apiResponseWithValidation.ConvertToJsonApiResponse();
		}

		public static JsonResourceResponse Create201CreatedResponse(this IApiCreatedResponse apiCreatedResponse, string newUri)
		{
			apiCreatedResponse.MessageID = StatusCodes.Status201Created;
			apiCreatedResponse.MessageText = "Created";
			apiCreatedResponse.CreatedAtUri.Uri = newUri;
			apiCreatedResponse.CreatedAtUri.Method = "GET";

			return apiCreatedResponse.ConvertToJsonApiResponse();
		}

		public static JsonResourceResponse Create204NoContentResponse(this IApiResponse apiResponse)
		{
			apiResponse.MessageID = StatusCodes.Status204NoContent;
			apiResponse.MessageText = "NoContent";

			return apiResponse.ConvertToJsonApiResponse();
		}

		public static JsonResourceResponse Create404NotFoundResponse(this IApiResponse apiResponse)
		{
			apiResponse.MessageID = StatusCodes.Status404NotFound;
			apiResponse.MessageText = "NotFound";

			return apiResponse.ConvertToJsonApiResponse();
		}
		public static JsonResourceResponse Create200SuccessResponse<T>(this IApiResponse apiResponse) where T : class
		{
			apiResponse.MessageID = StatusCodes.Status200OK;
			apiResponse.MessageText = "Success";

			return apiResponse.ConvertToJsonApiResponse();
		}
		public static JsonResourceResponse Create401UnauthorizedResponse(this IApiResponse unauthorizedRouteResult, string messageText)
		{
			unauthorizedRouteResult.MessageID = StatusCodes.Status401Unauthorized;
			unauthorizedRouteResult.MessageText = messageText;

			return unauthorizedRouteResult.ConvertToJsonApiResponse();
		}
		private static JsonResourceResponse ConvertToJsonApiResponse(this IApiResponse apiResponse)
		{
			return new JsonResourceResponse(apiResponse.MessageID, apiResponse);
		}
	}
}
