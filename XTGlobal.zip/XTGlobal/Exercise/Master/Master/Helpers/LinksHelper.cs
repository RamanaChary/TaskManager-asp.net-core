﻿using Microsoft.AspNetCore.Mvc;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;

namespace XTGlobal.API.Helpers
{
	public static class LinksHelper
	{
		public static void GenerateCollectionResourceLinks<T>(this CollectionResourceWithLinks<T> resource, IUrlHelper url, PagedList<T> resources, string actionName, BaseResourceParameters parameters, bool requireLinks = false) where T : class
		{
			resource?.Records?.ForEach(x =>
			{
				x.GenerateSingleResourceLinks(url, requireLinks);
			});

			resource.GeneratePageLinks<T>(url, resources, actionName, parameters);
		}

		private static void GeneratePageLinks<T>(this CollectionResourceWithLinks<T> resource, IUrlHelper url, PagedList<T> resources, string actionName, BaseResourceParameters parameters) where T : class
		{
			int originalPageNumber = parameters.PageNumber;
			resource?.PageLinks?.Add(new PageLink(url.Link(actionName, parameters), "Self", "GET"));

			if (resources.HasPrevious)
			{
				parameters.PageNumber = originalPageNumber - 1;
				resource?.PageLinks?.Add(new PageLink(url.Link(actionName, parameters), "Previous", "GET"));
			}

			if (resources.HasNext)
			{
				parameters.PageNumber = originalPageNumber + 1;
				resource?.PageLinks?.Add(new PageLink(url.Link(actionName, parameters), "Next", "GET"));
			}
		}

		public static void GenerateSingleResourceLinks<T>(this ResourceWithLinks<T> resource, IUrlHelper url, bool requireLinks = false) where T : class
		{
			//TO DO : Create these from data base action names
			resource?.Links?.Add(new Link(url.Link("GetTaskByTaskId", new { resource.Id, requireLinks }), "Self", "GET"));
			resource?.Links?.Add(new Link(url.Link("CreateTask", null), "CreateTask", "POST"));
			resource?.Links?.Add(new Link(url.Link("UpdateTask", new { resource.Id}), "UpdateTask", "PUT"));
			resource?.Links?.Add(new Link(url.Link("UpdatePartialTask", new { resource.Id}), "UpdatePartialTask", "PATCH"));
			resource?.Links?.Add(new Link(url.Link("DeleteTask", new { resource.Id}), "DeleteTask", "DeleteTask"));
		}
	}
}
