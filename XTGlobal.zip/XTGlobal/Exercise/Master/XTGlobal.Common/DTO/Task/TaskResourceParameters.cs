﻿using XTGlobal.Common.DTO.Infrastructure;

namespace XTGlobal.Common.DTO.Task
{
	public class TaskResourceParameters : BaseResourceParameters
	{
		public string Title { get; set; }
		public string Description { get; set; }
	}
}
