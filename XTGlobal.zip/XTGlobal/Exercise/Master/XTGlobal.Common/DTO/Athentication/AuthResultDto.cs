﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Athentication
{
    public class AuthResultDto
    {
		public string Token { get; set; }
		public bool Succeeded { get; set; }
		public List<string> Errors { get; set; }
	}
}
