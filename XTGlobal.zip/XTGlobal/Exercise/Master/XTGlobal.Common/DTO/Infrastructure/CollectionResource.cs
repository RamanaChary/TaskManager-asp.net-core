﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Infrastructure
{
    public class CollectionResource<T> where T: class
    {
		public CollectionResource() 
		{

		}
		public CollectionResource(List<Resource<T>> resources)
		{
			Records = resources;
		}
		public List<Resource<T>> Records { get; set; } = new List<Resource<T>>();
		public int Count => Records.Count;
	}

	public class CollectionResourceWithLinks<T> where T : class
	{
		public CollectionResourceWithLinks()
		{

		}
		public CollectionResourceWithLinks(List<ResourceWithLinks<T>> resourcesWithLinks)
		{
			Records = resourcesWithLinks;
		}
		public List<ResourceWithLinks<T>> Records { get; set; } = new List<ResourceWithLinks<T>>();
		public List<PageLink> PageLinks { get; set; } = new List<PageLink>();
		public int Count => Records.Count;
	}
}
