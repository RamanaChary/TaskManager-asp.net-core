﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Infrastructure
{
    public class CollectionResource<T> where T : class
    {
		public T Record { get; set; }

		public List<Link> Links { get; set; } = new List<Link>();

		public CollectionResource(T record)
		{
			Record = record;
		}
	}
}
