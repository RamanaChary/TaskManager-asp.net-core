﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Infrastructure
{
    public class CollectionResource<T> where T: class
    {
		public PagedList<Resource<T>> Records { get; set; } = new PagedList<Resource<T>>();
		public List<PageLink> PageLinks { get; set; } = new List<PageLink>();
		public int Count => Records.Count;
	}
}
