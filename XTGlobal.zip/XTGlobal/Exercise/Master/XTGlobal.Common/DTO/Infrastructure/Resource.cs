﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Infrastructure
{
    public class Resource<T> where T : class
    {
		public Resource()
		{

		}
		public Resource(T record)
		{
			Record = record;
		}
		public T Record { get; set; }
		public Guid Id { get; set; }
	}

	public class ResourceWithLinks<T> : Resource<T> where T : class
	{
		public ResourceWithLinks()
		{

		}
		public ResourceWithLinks(T record)
		{
			Record = record;
		}

		public List<Link> Links { get; set; } = new List<Link>();
	}
}
