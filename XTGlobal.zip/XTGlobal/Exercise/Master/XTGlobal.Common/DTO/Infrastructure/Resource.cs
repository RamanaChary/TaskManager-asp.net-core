﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Infrastructure
{
    public class Resource<T> where T : class
    {
		public T Record { get; set; }

		public List<Link> Links { get; set; } = new List<Link>();

		public Resource(T record)
		{
			Record = record;
		}
	}
}
