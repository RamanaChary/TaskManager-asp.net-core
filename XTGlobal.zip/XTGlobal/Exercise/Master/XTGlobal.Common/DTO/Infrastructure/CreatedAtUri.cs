﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Infrastructure
{
    public class CreatedAtUri
    {
		public string Uri { get; set; }
		public string Method { get; set; }
	}
}
