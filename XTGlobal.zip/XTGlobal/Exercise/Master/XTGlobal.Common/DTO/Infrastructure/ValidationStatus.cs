﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Infrastructure
{
    public class ValidationStatus
    {
		public string PropertyName { get; set; }
		public string ErrorMessage { get; set; }
	}
}
