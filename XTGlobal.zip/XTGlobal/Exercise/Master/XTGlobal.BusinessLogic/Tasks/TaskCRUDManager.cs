﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Tasks;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Tasks;

namespace XTGlobal.BusinessLogic.Tasks
{
	public class TaskCRUDManager : ITaskCRUDManager
	{
		private ITaskCRUDDAO _taskCRUDDAO = null;
		private IMapper _mapper = null;
		public TaskCRUDManager(ITaskCRUDDAO taskCRUDDAO, IMapper mapper)
		{
			_taskCRUDDAO = taskCRUDDAO ??
				throw new ArgumentNullException(nameof(taskCRUDDAO));
			_mapper = mapper ??
				throw new ArgumentNullException(nameof(mapper)); ;
		}

		public void Add(TaskDto task)
		{
			var model = _mapper.Map<DataAccess.Entity.EntityDataModels.Task>(task);
			_taskCRUDDAO.Add(model);
		}

		public void Delete(Guid taskID)
		{
			_taskCRUDDAO.Delete(taskID);
		}

		public void Update(TaskDto task)
		{
			var model = _mapper.Map<DataAccess.Entity.EntityDataModels.Task>(task);
			_taskCRUDDAO.Update(model);
		}

		public TaskDto TaskExists(Guid taskId)
		{
			return _mapper.Map<TaskDto>(_taskCRUDDAO.TaskExists(taskId));
		}
	}
}
