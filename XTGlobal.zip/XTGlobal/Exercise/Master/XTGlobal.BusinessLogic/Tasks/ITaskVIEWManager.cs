﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;

namespace XTGlobal.BusinessLogic.Tasks
{
    public interface ITaskVIEWManager
    {
		PagedList<TaskDto> GetAllTasks(TaskResourceParameters parameters);
		TaskDto GetTask(Guid taskId);
		PagedList<TaskDto> GetOverDueTasks(DateTime dueDate, TaskResourceParameters parameters);
		PagedList<TaskDto> GetCompletedTasks(TaskResourceParameters parameters);
    }
}
