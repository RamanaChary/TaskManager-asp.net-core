﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Task;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Task;

namespace XTGlobal.BusinessLogic.Task
{
	public class TaskVIEWManager : ITaskVIEWManager
	{
		private ITaskVIEWDAO _taskVIEWDAO = null;
		private IMapper _mapper = null; 
		public TaskVIEWManager(ITaskVIEWDAO taskVIEWDAO, IMapper mapper)
		{
			_taskVIEWDAO = taskVIEWDAO ??
				throw new ArgumentNullException(nameof(taskVIEWDAO));
			_mapper = mapper ??
				throw new ArgumentNullException(nameof(mapper));
		}

		public List<TaskDto> GetAllTasks(TaskResourceParameters parameters)
		{
			return _mapper.Map<List<TaskDto>> (_taskVIEWDAO.GetAllTasks(parameters));
		}

		public TaskDto GetTask(Guid taskId)
		{
			return _mapper.Map<TaskDto>(_taskVIEWDAO.GetTask(taskId));
		}

		public List<TaskDto> GetCompletedTasks()
		{
			return _mapper.Map<List<TaskDto>>(_taskVIEWDAO.GetCompletedTasks());
		}

		public List<TaskDto> GetOverDueTasks(DateTime dueDate)
		{
			return _mapper.Map<List<TaskDto>>(_taskVIEWDAO.GetOverDueTasks(dueDate));
		}
	}
}
