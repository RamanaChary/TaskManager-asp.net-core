﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Task;

namespace XTGlobal.BusinessLogic.Task
{
    public interface ITaskCRUDManager
    {
		void Add(TaskDto task);

		void Update(TaskDto task);

		void Delete(Guid taskID);

		TaskDto TaskExists(Guid taskId); 
	}
}
