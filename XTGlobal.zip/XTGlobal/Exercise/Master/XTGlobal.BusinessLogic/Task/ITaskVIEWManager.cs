﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Task;

namespace XTGlobal.BusinessLogic.Task
{
    public interface ITaskVIEWManager
    {
		List<TaskDto> GetAllTasks(TaskResourceParameters parameters);
		TaskDto GetTask(Guid taskId);
		List<TaskDto> GetOverDueTasks(DateTime dueDate);
		List<TaskDto> GetCompletedTasks();
    }
}
