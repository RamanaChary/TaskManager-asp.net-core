﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Athentication;
using XTGlobal.Common.DTO.User;
using XTGlobal.DataAccess.Authentication;

namespace XTGlobal.BusinessLogic.Athentication
{
	public class AuthCRUDManager : IAuthCRUDManager
	{
		private IAuthCRUDDAO _authCRUDDAO = null;
		private IMapper _mapper = null;
		public AuthCRUDManager(IAuthCRUDDAO authCRUDDAO, IMapper mapper)
		{
			_authCRUDDAO = authCRUDDAO ??
				throw new ArgumentNullException(nameof(authCRUDDAO));
			_mapper = mapper ??
				throw new ArgumentNullException(nameof(mapper));
		}
		public UserDto Login(UserDto userDto)
		{
			return _mapper.Map<UserDto>(_authCRUDDAO.LogIn(userDto));
		}
	}
}
