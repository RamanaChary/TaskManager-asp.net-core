﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Athentication;
using XTGlobal.Common.DTO.User;
using XTGlobal.DataAccess.Authentication;

namespace XTGlobal.BusinessLogic.Athentication
{
	public class AuthCRUDManager : IAuthCRUDManager
	{
		private IAuthCRUDDAO _authCRUDDAO;
		private IMapper _mapper;
		public AuthCRUDManager(IAuthCRUDDAO authCRUDDAO, IMapper mapper)
		{
			_authCRUDDAO = authCRUDDAO;
			_mapper = mapper;
		}
		public UserDto Login(UserDto userDto)
		{
			return _mapper.Map<UserDto>(_authCRUDDAO.LogIn(userDto));
		}

		public bool ValidateRoute(string email, string routeTemplate, string method)
		{
			return _authCRUDDAO.ValidateRoute(email, routeTemplate, method);
		}
	}
}
