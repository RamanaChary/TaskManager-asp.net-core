﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Athentication;
using XTGlobal.Common.DTO.User;

namespace XTGlobal.BusinessLogic.Athentication
{
    public interface IAuthCRUDManager
    {
		UserDto Login(UserDto userDto);
    }
}
