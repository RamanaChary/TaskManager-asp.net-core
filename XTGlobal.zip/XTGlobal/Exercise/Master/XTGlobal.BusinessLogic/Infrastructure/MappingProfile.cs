﻿using AutoMapper;
using XTGlobal.Common.DTO.Tasks;
using XTGlobal.Common.DTO.User;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.BusinessLogic.Infrastructure
{
	public class MappingProfile : Profile
    {
		public MappingProfile()
		{
			// Add as many of these lines as you need to map your objects
			CreateMap<Task, TaskDto>()
				.ForMember(dest => dest.DueDate, opts => opts.MapFrom(x => x.DueDate.ToShortDateString()))
				.ReverseMap();
			CreateMap<User, UserDto>();
		}
	}
}
