﻿using Microsoft.Extensions.DependencyInjection;
using XTGlobal.BusinessLogic.Athentication;
using XTGlobal.BusinessLogic.Task;
using XTGlobal.DataAccess.Authentication;
using XTGlobal.DataAccess.Infrastructure;
using XTGlobal.DataAccess.Task;

namespace XTGlobal.BusinessLogic.Infrastructure
{
	/// <summary>
	/// Inject logic layer dependencies 
	/// </summary>
	public static class LogicDependencyResolver
    {
		public static void AddLogicDependency(this IServiceCollection services)
		{
			services.AddTransient<ITaskVIEWManager, TaskVIEWManager>();
			services.AddTransient<ITaskCRUDManager, TaskCRUDManager>();
			services.AddTransient<IAuthCRUDManager, AuthCRUDManager>();
			services.AddTransient<ITaskVIEWDAO, TaskVIEWDAO>();
			services.AddTransient<ITaskCRUDDAO, TaskCRUDDAO>();
			services.AddTransient<IAuthCRUDDAO, AuthCRUDDAO>();
			services.AddTransient<IDataSource, DataSource>();
		}
    }
}
