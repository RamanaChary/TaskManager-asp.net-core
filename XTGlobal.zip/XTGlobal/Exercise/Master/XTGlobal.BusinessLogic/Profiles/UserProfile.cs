﻿using AutoMapper;
using XTGlobal.Common.DTO.User;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.BusinessLogic.Profiles
{
	public class UserProfile : Profile
	{
		public UserProfile()
		{
			CreateMap<User, UserDto>();
		}
	}
}
