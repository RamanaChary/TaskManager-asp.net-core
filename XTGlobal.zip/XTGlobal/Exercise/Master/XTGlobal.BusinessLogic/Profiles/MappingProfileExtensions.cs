﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.BusinessLogic.Profiles
{
	public static class MappingProfileExtensions
	{
		public static void AddBusinessLayerMappingProfiles(this IMapperConfigurationExpression mc)
		{
			mc.AddProfile(new CommonMappingProfile());
			mc.AddProfile(new TaskProfile());
			mc.AddProfile(new UserProfile());
		}
	}
}
