﻿using AutoMapper;
using XTGlobal.Common.DTO.Tasks;
using XTGlobal.DataAccess.Entity.EntityDataModels;

namespace XTGlobal.BusinessLogic.Profiles
{
	public class TaskProfile : Profile
	{
		public TaskProfile()
		{
			CreateMap<Task, TaskDto>()
				.ForMember(dest => dest.DueDate, opts => opts.MapFrom(x => x.DueDate.ToShortDateString()))
				.ReverseMap();
		}
	}
}
