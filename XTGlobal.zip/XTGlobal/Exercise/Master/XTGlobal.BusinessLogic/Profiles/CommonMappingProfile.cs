﻿using AutoMapper;
using XTGlobal.Common.DTO.Infrastructure;

namespace XTGlobal.BusinessLogic.Profiles
{
	public class CommonMappingProfile : Profile
    {
		public CommonMappingProfile()
		{
			CreateMap(typeof(PagedList<>), typeof(PagedList<>));
		}
	}
}
