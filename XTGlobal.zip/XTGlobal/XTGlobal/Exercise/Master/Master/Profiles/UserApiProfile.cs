﻿using AutoMapper;
using XTGlobal.API.ApiModels.Athentication.Login;
using XTGlobal.Common.DTO.User;

namespace XTGlobal.API.Profiles
{
	public class UserApiProfile : Profile
    {
		public UserApiProfile()
		{
			CreateMap<UserForLoginDto, UserDto>();
		}
    }
}
