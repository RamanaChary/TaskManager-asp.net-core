﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using XTGlobal.API.ApiModels.Athentication.Login;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Athentication;
using XTGlobal.Common.DTO.Athentication;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.User;
using XTGlobal.API.Helpers;

namespace XTGlobal.API.Controllers.Authentication
{
	[Route("api/Auth")]
	public class AuthController : ControllerBase
	{
		private IAuthCRUDLogic _authCRUDManager;
		private IMapper _mapper;
		private AppSettings _appSettings;

		public AuthController(IAuthCRUDLogic authCRUDManager, IMapper mapper, AppSettings appSettings)
		{
			_authCRUDManager = authCRUDManager;
			_mapper = mapper;
			_appSettings = appSettings;
		}

		[HttpGet]
		[Route("Home", Name = "Home")]
		[AllowAnonymous]
		public ActionResult Home()
		{
			return Ok("Welcome to Task management REST API...");
		}

		[HttpPost]
		[Route("LogIn", Name = "LogIn")]
		[AllowAnonymous]
		[ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(IApiResponse))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiSingleResourceResponse<AuthResultDto>))]
		[ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(IApiErrorResponse))]
		public IActionResult LogIn([FromBody] UserForLoginDto loginDto
			, [FromServices] IApiSingleResourceResponse<AuthResultDto> apiSingleResourceResponse
			, [FromServices] IApiResponse apiResponse
			, [FromServices] IApiErrorResponse apiErrorResponse)
		{
			try
			{
				var userDto = _authCRUDManager.Login(_mapper.Map<UserDto>(loginDto));
				if (userDto == null)
				{
					return apiResponse.Create404NotFoundResponse();
				}

				var tokenHandler = new JwtSecurityTokenHandler();
				var key = Encoding.ASCII.GetBytes(_appSettings.JwtSecret);
				var tokenDescriptor = new SecurityTokenDescriptor()
				{
					Subject = new ClaimsIdentity(new[]
					{
						new Claim(ClaimTypes.Name, loginDto.Email),
						new Claim(JwtRegisteredClaimNames.Sub, loginDto.Email),
						new Claim(JwtRegisteredClaimNames.Email, loginDto.Email)
					}),
					Expires = DateTime.UtcNow.AddMinutes(_appSettings.ExpiresIn),
					SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
				};

				var token = tokenHandler.CreateToken(tokenDescriptor);
				var tokenString = tokenHandler.WriteToken(token);

				apiSingleResourceResponse.Result = new Resource<AuthResultDto>(new AuthResultDto()
				{
					Token = tokenString,
					RefreshToken = tokenString,
					Expires = tokenDescriptor.Expires?.ToString()
				});

				return apiSingleResourceResponse.Create200SuccessResponse<AuthResultDto>();
			}
			catch (Exception ex)
			{
				return apiErrorResponse.Create500InternalServerErrorResponse(ex.Message);
			}
		}
	}
}