﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using AutoMapper;
using Marvin.Cache.Headers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using XTGlobal.API.Infrastructure;
using XTGlobal.BusinessLogic.Tasks;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;
using XTGlobal.API.Helpers;

namespace XTGlobal.API.Controllers.Tasks
{
	/// <summary>
	/// Controller to perform GET/VIEW operations against Task.
	/// </summary>
	[Route("api/TaskVIEW/Tasks")]
	//[HttpCacheExpiration(CacheLocation = CacheLocation.Public, MaxAge = 600)]
	//[HttpCacheValidation(MustRevalidate = true)]	
	public class TaskVIEWController : BaseController<TaskDto>
	{
		private ITaskVIEWLogic _taskVIEWLogic;
		public TaskVIEWController(ITaskVIEWLogic taskVIEWLogic, AppSettings appSettings
			, IMapper mapper) : base(mapper, appSettings)
		{
			_taskVIEWLogic = taskVIEWLogic;
		}

		/// <summary>
		/// Get all tasks by criteria
		/// </summary>
		/// <param name="parameters"></param>
		/// <param name="apiResponse"></param>
		/// <returns>A collection of tasks</returns>
		/// <response code="401">Unauthorized request</response>
		/// <response code="200">Request is processed successfully</response>
		/// <response code="401">Request could not be processed due to internal server error</response>
		[HttpGet]
		[Route("", Name = "GetAllTasks")]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponse<TaskDto>))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponseWithLinks<TaskDto>))]
		public IActionResult GetAllTasks([FromQuery] TaskResourceParameters parameters)
        {
			try
			{
				var userTasks = _taskVIEWLogic.GetAllTasks(parameters);

				if(parameters.requireLinks)
				{
					return Create200SuccessCollectionResourceReponseWithLinks(userTasks, parameters);
				}

				return Create200SuccessCollectionResourceReponse(userTasks, parameters);
			}
			catch (Exception ex)
			{
				return Create500InternalServerErrorResponse(ex.Message);
			}
        }

		[HttpGet]
		[Route("{Id}", Name = "GetTaskByTaskId")]
		[ProducesResponseType(StatusCodes.Status404NotFound, Type = typeof(IApiResponse))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiSingleResourceResponse<TaskDto>))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiSingleResourceResponseWithLinks<TaskDto>))]
		public IActionResult GetTaskByTaskId([FromRoute] Guid Id
			,[FromQuery] bool requireLinks)
		{
			try
			{
				var userTask = _taskVIEWLogic.GetTask(Id);

				if (userTask == null)
				{
					return Create404NotFoundResponse();
				}

				if (requireLinks)
				{
					return Create200SuccessSingleResourceReponseWithLinks(userTask);
				}

				return Create200SuccessSingleResourceReponse(userTask);
			}
			catch (Exception ex)
			{
				return Create500InternalServerErrorResponse(ex.Message);
			}
		}

		[HttpGet]
		[Route("OverDue", Name = "GetOverDueTasks")]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponse<TaskDto>))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponseWithLinks<TaskDto>))]
		public IActionResult GetOverDueTasks([FromQuery] string dueDate
			, [FromQuery] TaskResourceParameters parameters)
		{
			DateTime overDueDate = string.IsNullOrWhiteSpace(dueDate) ? DateTime.UtcNow : Convert.ToDateTime(dueDate);
			try
			{
				var userTasks = _taskVIEWLogic.GetOverDueTasks(overDueDate, parameters);

				if(parameters.requireLinks)
				{
					return Create200SuccessCollectionResourceReponseWithLinks(userTasks, parameters);
				}

				return Create200SuccessCollectionResourceReponse(userTasks, parameters);
			}
			catch (Exception ex)
			{
				return Create500InternalServerErrorResponse(ex.Message);
			}
		}

		[HttpGet]
		[Route("Completed", Name = "GetCompletedTasks")]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponse<TaskDto>))]
		[ProducesResponseType(StatusCodes.Status200OK, Type = typeof(IApiCollectionResourceResponseWithLinks<TaskDto>))]
		public IActionResult GetCompletedTasks([FromQuery] TaskResourceParameters parameters)
		{
			try
			{
				var userTasks = _taskVIEWLogic.GetCompletedTasks(parameters);

				if(parameters.requireLinks)
				{
					return Create200SuccessCollectionResourceReponseWithLinks(userTasks, parameters);
				}

				return Create200SuccessCollectionResourceReponse(userTasks, parameters);
			}
			catch (Exception ex)
			{
				return Create500InternalServerErrorResponse(ex.Message);
			}
		}
	}
}
