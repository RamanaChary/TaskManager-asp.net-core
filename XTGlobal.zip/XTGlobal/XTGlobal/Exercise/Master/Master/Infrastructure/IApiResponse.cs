﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using XTGlobal.Common.DTO.Infrastructure;

namespace XTGlobal.API.Infrastructure
{
	public interface IApiResponse
	{
		int MessageID { get; set; }
		string MessageText { get; set; }		
	}

	public interface IApiResponseWithValidation : IApiResponse
	{
		bool HasValidationErrors { get; }
		List<ValidationStatus> ValidationResult { get; set; }
	}
	public interface IApiCollectionResourceResponse<T> : IApiResponse where T : class
    {
		CollectionResource<T> Result { get; set; }
	}

	public interface IApiCollectionResourceResponseWithLinks<T> : IApiResponse where T : class
	{
		CollectionResourceWithLinks<T> Result { get; set; }
	}

	public interface IApiCollectionResourceResponseWithValidation<T> : IApiResponseWithValidation where T : class
	{
		CollectionResource<T> Result { get; set; }
	}

	public interface IApiSingleResourceResponse<T> : IApiResponse where T : class
	{
		Resource<T> Result { get; set; }
	}

	public interface IApiSingleResourceResponseWithLinks<T> : IApiResponse where T : class
	{
		ResourceWithLinks<T> Result { get; set; }
	}

	public interface IApiSingleResourceResponseWithValidation<T> : IApiResponseWithValidation where T : class
	{
		Resource<T> Result { get; set; }
	}

	public interface IApiCreatedResponse : IApiResponse
	{
		CreatedAtUri CreatedAtUri { get; set; }
	}

	public interface IApiErrorResponse : IApiResponse
	{
		ServerError ServerError { get; set; }
	}
}
