﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Athentication;
using XTGlobal.Common.DTO.User;

namespace XTGlobal.BusinessLogic.Athentication
{
    public interface IAuthCRUDLogic
    {
		UserDto Login(UserDto userDto);
		bool ValidateRoute(string email, string routeTemplate, string method);
	}
}
