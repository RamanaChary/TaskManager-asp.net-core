﻿using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Tasks;

namespace XTGlobal.BusinessLogic.Tasks
{
    public interface ITaskCRUDLogic
    {
		Guid Add(TaskDto task);

		void Update(TaskDto task);

		void Delete(Guid taskID);

		TaskDto TaskExists(Guid taskId); 
	}
}
