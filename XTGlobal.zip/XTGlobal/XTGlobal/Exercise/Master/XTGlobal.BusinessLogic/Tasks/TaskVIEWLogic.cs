﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Tasks;

namespace XTGlobal.BusinessLogic.Tasks
{
	public class TaskVIEWLogic : ITaskVIEWLogic
	{
		private ITaskVIEWDAO _taskVIEWDAO;
		private IMapper _mapper; 
		public TaskVIEWLogic(ITaskVIEWDAO taskVIEWDAO, IMapper mapper)
		{
			_taskVIEWDAO = taskVIEWDAO;
			_mapper = mapper;
		}

		public PagedList<TaskDto> GetAllTasks(TaskResourceParameters parameters)
		{
			return _mapper.Map <PagedList<TaskDto>> (_taskVIEWDAO.GetAllTasks(parameters));
		}

		public TaskDto GetTask(Guid taskId)
		{
			return _mapper.Map<TaskDto>(_taskVIEWDAO.GetTask(taskId));
		}

		public PagedList<TaskDto> GetCompletedTasks(TaskResourceParameters parameters)
		{
			return _mapper.Map<PagedList<TaskDto>>(_taskVIEWDAO.GetCompletedTasks(parameters));
		}

		public PagedList<TaskDto> GetOverDueTasks(DateTime dueDate, TaskResourceParameters parameters)
		{
			return _mapper.Map<PagedList<TaskDto>>(_taskVIEWDAO.GetOverDueTasks(dueDate, parameters));
		}
	}
}
