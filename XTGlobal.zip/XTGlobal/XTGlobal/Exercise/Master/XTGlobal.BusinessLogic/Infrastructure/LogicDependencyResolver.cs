﻿using Microsoft.Extensions.DependencyInjection;
using XTGlobal.BusinessLogic.Athentication;
using XTGlobal.BusinessLogic.Tasks;
using XTGlobal.DataAccess.Authentication;
using XTGlobal.DataAccess.Infrastructure;
using XTGlobal.DataAccess.Tasks;

namespace XTGlobal.BusinessLogic.Infrastructure
{
	/// <summary>
	/// Inject logic layer dependencies 
	/// </summary>
	public static class LogicDependencyResolver
    {
		public static void AddLogicDependency(this IServiceCollection services)
		{
			services.AddTransient<ITaskVIEWLogic, TaskVIEWLogic>();
			services.AddTransient<ITaskCRUDLogic, TaskCRUDLogic>();
			services.AddTransient<IAuthCRUDLogic, AuthCRUDLogic>();
			services.AddTransient<ITaskVIEWDAO, TaskVIEWDAO>();
			services.AddTransient<ITaskCRUDDAO, TaskCRUDDAO>();
			services.AddTransient<IAuthCRUDDAO, AuthCRUDDAO>();
			services.AddTransient<IDataSource, DataSource>();
		}
	}
}
