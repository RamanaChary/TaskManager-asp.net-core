﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Infrastructure
{
	public class AppSettings
	{
		public string JwtSecret { get; set; }
		public string Issuer { get; set; }
		public string Audience { get; set; }
		public int ExpiresIn { get; set; }
		public bool UseJwtAuthentication { get; set; }
		public bool UseCaching { get; set; }
	}
}
