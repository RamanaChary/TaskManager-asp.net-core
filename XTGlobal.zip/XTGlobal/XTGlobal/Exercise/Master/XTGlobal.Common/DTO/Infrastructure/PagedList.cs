﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XTGlobal.Common.DTO.Infrastructure
{
    public class PagedList<T> where T : class
    {
		public int CurrentPage { get; private set; }
		public int PreviousPage { get; private set; }
		public int NextPage { get; private set; }
		public int FirstPage { get; private set; }
		public int LastPage { get; private set; }
		public int TotalPages { get; private set; }
		public int PageSize { get; private set; }
		public int TotalCount { get; private set; }
		public bool HasPrevious => (CurrentPage > 1);
		public bool HasNext => (CurrentPage < TotalPages);
		public bool HasFirst => (TotalPages > 0);
		public bool HasLast => (TotalPages > 0);
		public List<T> Items { get; set; } = new List<T>();

		public PagedList()
		{

		}

		public PagedList(List<T> items, int count, int pageNumber, int pageSize)
		{
			TotalPages = (int)Math.Ceiling(count / (double)pageSize);
			TotalCount = count;
			PageSize = pageSize;
			CurrentPage = pageNumber;
			PreviousPage = HasPrevious ? (CurrentPage > TotalPages ? TotalPages - 1 : CurrentPage - 1) : CurrentPage;
			NextPage = HasNext ? CurrentPage + 1 : CurrentPage;
			FirstPage = 1;
			LastPage = TotalPages;			
			Items = items;
		}

		public static PagedList<T> Create(IQueryable<T> source, int pageNumber, int pageSize)
		{
			var count = source.Count();
			var items = source.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();

			return new PagedList<T>(items, count, pageNumber, pageSize);
		}
	}
}
