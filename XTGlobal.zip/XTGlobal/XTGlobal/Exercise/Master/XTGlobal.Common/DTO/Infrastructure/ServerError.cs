﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Infrastructure
{
	public class ServerError
	{
		public Guid ErrorId { get; set; }
		public string ErrorText { get; set; }
	}
}
