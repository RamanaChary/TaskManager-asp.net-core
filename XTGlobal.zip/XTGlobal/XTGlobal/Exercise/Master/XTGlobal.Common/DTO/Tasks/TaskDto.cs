﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XTGlobal.Common.DTO.Tasks
{
    public class TaskDto
    {
		public Guid TaskID { get; set; }
		public string Title { get; set; }
		public string Description { get; set; }
		public string DueDate { get; set; }
		public int? UserID { get; set; }
		public bool IsCompleted { get; set; }
	}
}
