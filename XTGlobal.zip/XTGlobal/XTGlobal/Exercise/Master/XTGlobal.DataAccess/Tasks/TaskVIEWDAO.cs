﻿using System;
using System.Linq;
using XTGlobal.Common.DTO.Infrastructure;
using XTGlobal.Common.DTO.Tasks;
using XTGlobal.DataAccess.Entity.EntityDataModels;
using XTGlobal.DataAccess.Infrastructure;

namespace XTGlobal.DataAccess.Tasks
{
	public class TaskVIEWDAO : ITaskVIEWDAO
	{
		private IDataSource _dataSource;

		public TaskVIEWDAO(IDataSource dataSource)
		{
			_dataSource = dataSource;
		}

		public PagedList<Task> GetAllTasks(TaskResourceParameters parameters)
		{
			var collection = _dataSource.Tasks?.AsQueryable<Task>();

			if(!string.IsNullOrWhiteSpace(parameters.Title))
			{
				collection = collection.Where(items => items.Title.Contains(parameters.Title));
			}
			if(!string.IsNullOrWhiteSpace(parameters.Description))
			{
				collection = collection.Where(items => items.Description.Contains(parameters.Description));
			}

			return PagedList<Task>.Create(collection, parameters.PageNumber, parameters.PageSize);
		}

		public Task GetTask(Guid taskId)
		{
			return _dataSource.Tasks?.Find(x => x.TaskID == taskId);
		}

		public PagedList<Task> GetCompletedTasks(TaskResourceParameters parameters)
		{
			var collection = _dataSource.Tasks?.AsQueryable<Task>();

			collection = collection.Where(t => t.IsCompleted);
			if (!string.IsNullOrWhiteSpace(parameters.Title))
			{
				collection = collection.Where(items => items.Title == parameters.Title);
			}
			if (!string.IsNullOrWhiteSpace(parameters.Description))
			{
				collection = collection.Where(items => items.Description == parameters.Description);
			}

			return PagedList<Task>.Create(collection, parameters.PageNumber, parameters.PageSize);
		}

		public PagedList<Task> GetOverDueTasks(DateTime dueDate, TaskResourceParameters parameters)
		{
			var collection = _dataSource.Tasks?.AsQueryable<Task>();

			collection = collection.Where(t => t.DueDate != DateTime.MinValue &&
									t.DueDate.CompareTo(dueDate) < 0 &&
									!t.IsCompleted);

			if (!string.IsNullOrWhiteSpace(parameters.Title))
			{
				collection = collection.Where(items => items.Title == parameters.Title);
			}
			if (!string.IsNullOrWhiteSpace(parameters.Description))
			{
				collection = collection.Where(items => items.Description == parameters.Description);
			}

			return PagedList<Task>.Create(collection, parameters.PageNumber, parameters.PageSize);
		}
	}
}
